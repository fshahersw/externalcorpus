# Optional enrichment and integration

## Explicit official URLs

The warning-letter and settlement tools do not invent URLs or resolve a capped FDA list automatically. Provide a reviewed JSONL file containing source IDs and explicit URLs on the supported hosts. A line has this structure:

```json
{"source_id":"source-record-id","title":"Reviewed source title","source_url":"https://www.fda.gov/your-reviewed-path"}
```

Replace the example path with a real source; the example is not a download target.

```text
python -m corpus_workbench enrich-plan reviewed-urls.jsonl --kind warning-letter
python -m corpus_workbench enrich-run workbench-state/warning-letter-plan.json
python -m corpus_workbench enrich-run workbench-state/warning-letter-plan.json --execute --max-jobs 10
python -m corpus_workbench import-receipts
```

Use `--kind settlement` or `--kind opinion` for those collections. Without `--execute`, no download is performed. Jobs are bounded, allowlisted, and robots-checked; cross-host redirects are held for a separately reviewed URL. Saved responses get SHA-256 receipts. Refusals / failed requests must be reviewed; they are not evidence of absent documents. Pending NAAG links on the original collecting machine have not been transferred or executed here.

## DailyMed

```text
python -m corpus_workbench label-history YOUR-VERIFIED-SETID --execute --max-pages 10
python -m corpus_workbench enrich-run workbench-state/label-versions-plan.json --execute --max-jobs 10
python -m corpus_workbench import-receipts
```

Replace `YOUR-VERIFIED-SETID` with an actual UUID identifying the label. The first command fetches the history and plans versions; the second downloads selected versions; the third imports saved files. Publication history is not FDA approval history. The live API response shapes have not been tested in this environment; parsing fixtures are tested. The archive and enrichment adapters share the namespaced `dailymed.setid` identifier; a regression test checks cross-adapter related records.

## Case lookup

Set `COURTLISTENER_TOKEN` in the local process environment, then:

```text
python -m corpus_workbench case-lookup "509 U.S. 579" --execute
```

Only the citation string is sent, not a document. The lookup result is saved as a receipt and does not automatically download opinions or establish positive/negative treatment. Provider credentials are not written into the HTML or package. This live integration is unvalidated here.

## JSONL for your existing extraction engines

The importer accepts one object per line:

```json
{"record":{"collection":"official-orders","collection_title":"Official orders","source_id":"stable-source-123","title":"Reviewed order","source_url":"https://official-source.example/order.pdf","jurisdiction":"NJ","qualification":"Saved snapshot; verify currency."},"pages":[{"label":"Page 1","kind":"pdf_page","text":"Exact extracted text"}]}
```

`python -m corpus_workbench import-jsonl extracted.jsonl` writes into the sidecar and scans citations. Keep real physical page anchors only where the extraction provides them. `text_segment` is the appropriate kind for HTML/API text with no physical page mapping. Do not pass private/licensed material unless authorized for the intended local use.

## Main-platform handoff

`integration/platform-receiver.mjs` exports `validateEvidencePackage()` and `installEvidenceReceiver()`. The host application must explicitly configure the exact workbench origin and source window, confirm the selection with the user, authorize record access server-side, and store a pending evidence attachment through its existing operation. A successful acknowledgment means received, not an AI task submitted.

The workbench can prepare and export packages without this receiver. The receiver is not injected into `uptodate` automatically; no existing agent or Skylar configuration has been changed. A production integration requires a shared authenticated origin or appropriate secure proxy, not exposing the development server to the network.

## Scope left for a full integration

Run source-backed full-corpus imports; validate each collection's API shape and extraction completeness; add automatic warning-letter URL resolution and review; extend state-citation aliases by jurisdiction; import verified case results into the relationship view; test provider endpoints and OCR on representative originals; add authentication and durable workspace handoff in the production application. Existing judge/county specialty views remain in the original archive.
