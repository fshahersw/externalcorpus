# Corpus Workbench — additive upgrade

A runnable, separate workbench for `fshahersw/externalcorpus`. It improves search, evidence reading, citations, saved versions, related records, and evidence handoffs without rewriting the original archive.

**Trellis content, source files, release assets, licensing metadata, repository visibility, and production application remain unchanged.** This package has not been pushed to GitHub or deployed.

## See it immediately

Open `corpus-workbench-preview.html` in Chrome or Edge. It is an offline interactive UI with explicitly synthetic records. Search, filters, reading, citations, versions, comparison, and the evidence tray work against those fixtures. It never represents fixtures as your real corpus.

For the running Python demo, double-click `START_DEMO.cmd` on Windows, or run:

```text
python -m corpus_workbench demo --open
```

Python 3.11 or newer with SQLite FTS5 is required. The demo, search store, web server, and limited citation fallback use the standard library. Native PDF extraction needs pypdf; broader citation detection can use eyecite.

## Connect the real corpus

Extract this package into **a new folder**, separate from the original archive. Start your existing archive normally at `http://127.0.0.1:8769`.

In a terminal in this package folder:

```text
python -m pip install -r requirements.txt
python -m corpus_workbench sync --collection all --max-records 50 --max-seconds 15
python -m corpus_workbench serve --open
```

On Windows `py -3` can replace `python`. `START_WORKBENCH.cmd` opens the new workbench after import; it does not start the original archive or silently acquire data.

`sync` makes GET requests to registered read-only archive APIs and writes only `workbench-state/` in this new folder. Limits apply **per collection**, not to the whole `all` batch. Repeating a command resumes its saved cursor. A bounded import is a sample of the archive, not a complete migration. Each individual archive request also has its own timeout, so a pass may finish its current request after its time budget.

The original archive remains on port 8769; the new workbench runs on port 8770. It is not a replacement for the original application's routes or its specialized judge/county dashboards. Open the original archive for those views.

## What is implemented

- One SQLite FTS5 index over imported records: ordinary all-word search, explicit quoted phrases, any-word mode, BM25 relevance, title/citation weighting, source and availability filters, deterministic pagination, and source coverage.
- Immutable document versions carrying source metadata and text hashes. The reader distinguishes physical PDF pages, sections, and text segments rather than inventing page citations.
- Citation extraction per page; parser-version-aware reprocessing; retryable failed scans; transactional citation replacement; accurate totals and pagination beyond 80 results; local authority matching with edition ambiguity preserved.
- A deliberately limited built-in citation detector. Installing eyecite enables broader detection and causes rescanning under a different parser signature. Universal state-citation normalization, short-form resolution, negative treatment, and good-law verification are not claimed.
- Evidence-backed relationships using explicit namespaced source identifiers. No automatic merging by judge, company, product, or party name.
- Responsive UI: three browsing hubs, source-aware search, record reader, citation/related/version/source tabs, saved-version comparison, evidence tray, and source health.
- Research / Office / Discovery evidence packages with record IDs, versions, locations, hashes, and qualifications. Export works locally. `integration/platform-receiver.mjs` is a separately tested optional receiver, **not installed in production**. No action is described as submitted without an application acknowledgment.
- Bounded resumable import adapters for 14 registered archive collections. The generic API may expose only a text preview; such records remain marked partial. The original archive's API limits and validation gates are not bypassed.
- Native PDF extraction, optional separate OCR derivatives, JSONL ingestion, and bounded opt-in enrichment tools for explicit official warning-letter/settlement/opinion URLs, DailyMed history, and CourtListener citation lookup.

## Court PDF processing

```text
python -m corpus_workbench sync --collection court-documents --max-records 100 --max-seconds 120 --extract-originals
```

Repeat to continue. Changing between API-text and PDF-page modes restarts the pagination cursor for that mode; existing identical versions are deduplicated. PDFs are downloaded temporarily from your local archive and processed into the sidecar; originals are not rewritten. API artifact downloads are capped at 100 MiB. Large, inaccessible, or unsupported originals require separate handling. The pass pauses at an unavailable record rather than silently skipping evidence.

For an explicitly selected local PDF:

```text
python -m corpus_workbench extract-pdf "C:\path\document.pdf" --source-id "your-stable-id" --title "Document title" --source-url "https://official-source.example/document.pdf"
```

Empty pages are flagged. `--ocr` requires an existing OCRmyPDF installation and writes a new derivative in the sidecar. OCR was not run on the complete corpus here. OCR confidence is not represented as verified accuracy. For an OCR-derived import the stored file hash identifies the processed derivative, not an evidentiary hash of the original scan; keep the original separately.

## Refresh and inspect

```text
python -m corpus_workbench sync --collection agency-documents --refresh --max-records 100 --max-seconds 120
python -m corpus_workbench scan --max-records 1000
python -m corpus_workbench health
```

`--refresh` begins a new upstream enumeration; it does not delete saved versions. For a full refresh, start with `--refresh` once, then continue without that flag. Source deletions, source-side reordering during pagination, and tombstone reconciliation need separate review. Do not use concurrent CLI writers against the same state folder.

## External enrichment is opt-in

See `docs/ENRICHMENT.md`. Merely starting the application does not crawl, buy API calls, send documents to a model, or use a provider key. No key is included in this package. Do not paste private text into the public citation lookup command.

## Verification and limits

See `VERIFICATION.md` for fresh results. All corpus examples used in the UI tests are synthetic. The full multi-gigabyte corpus was not mounted, no external provider enrichment was executed, and production authentication / SSO / authorization have not been connected. The code is a local development companion, not an internet-exposed production server.
