"""Bounded read-only import from the existing archive. All new data stays in Store."""
from __future__ import annotations
import json,time,re,tempfile
from pathlib import Path
from urllib.request import Request,build_opener,HTTPRedirectHandler
from urllib.parse import urlsplit,urlencode,urljoin
from .citations import scan

COLLECTIONS={
 'bulk-law':('Saved law','states','/api/documents',{'dataset':'open_us_law','view':'sources'}),
 'agency-documents':('Agency & science','federal','/api/area/agency-documents',{}),
 'source-documents':('Source documents','federal','/api/area/source-documents',{}),
 'saved-pages':('Saved web pages','states','/api/area/saved-pages',{}),
 'uscourts':('U.S. Courts publications','courts','/api/area/uscourts',{}),
 'court-documents':('Court documents','courts','/api/area/court-documents',{}),
 'public-laws':('Public laws','federal','/api/area/public-laws',{}),
 'federal-register':('Federal Register','federal','/api/area/federal-register',{}),
 'state-proceedings':('State mass torts','courts','/api/area/state-proceedings',{}),
 'mdl-documents':('MDL documents','courts','/api/area/mdl-documents',{}),
 'mdl-activity':('MDL docket activity','courts','/api/area/mdl-activity',{}),
 'courts':('Court registry','courts','/api/area/courts',{}),
 'counsel-directory':('Counsel & firms','courts','/api/area/counsel-directory',{}),
 'expert-rulings':('Expert rulings','courts','/api/area/expert-rulings',{}),
}
class SameOriginRedirect(HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        if urlsplit(req.full_url).netloc!=urlsplit(newurl).netloc or urlsplit(newurl).scheme not in ('http','https'):
            raise ValueError('Archive redirect outside configured loopback origin refused')
        return super().redirect_request(req,fp,code,msg,headers,newurl)

class ArchiveClient:
    def __init__(self,base_url='http://127.0.0.1:8769',timeout=25):
        u=urlsplit(base_url)
        if u.scheme not in ('http','https') or u.hostname not in ('127.0.0.1','localhost','::1') or u.username or u.password or u.path not in ('','/') or u.query or u.fragment:
            raise ValueError('Use the exact loopback origin of the archive, without credentials, query, or path')
        try: u.port
        except ValueError: raise ValueError('Invalid archive port') from None
        self.base_url=base_url.rstrip('/');self.timeout=timeout;self.opener=build_opener(SameOriginRedirect())
    def get(self,path,params=None,binary=False):
        if not path.startswith(('/api/','/supplement-files/','/files/','/bulk-files/','/agency-safety/')) or '..' in path or path.startswith('//'):
            raise ValueError('Only registered archive API/artifact paths may be read')
        url=self.base_url+path+('?' + urlencode(params) if params else '')
        req=Request(url,headers={'User-Agent':'CorpusWorkbench/1.0','Accept':'application/json' if not binary else 'application/pdf,application/octet-stream'})
        maximum=100*1024*1024 if binary else 8*1024*1024
        with self.opener.open(req,timeout=self.timeout) as response:
            data=response.read(maximum+1)
            if len(data)>maximum: raise ValueError('Archive response exceeds bounded import size')
            if binary: return data
        result=json.loads(data)
        if not isinstance(result,dict): raise ValueError('Expected archive JSON object')
        return result
    def listing(self,collection,page,limit):
        title,hub,path,filters=COLLECTIONS[collection]
        return self.get(path,{**filters,'page':page,'limit':limit})
    def detail(self,collection,id):
        path='/api/record' if collection=='bulk-law' else COLLECTIONS[collection][2]+'/item'
        return self.get(path,{'id':id})
    def original(self,url):
        u=urlsplit(url)
        if u.netloc and (u.scheme,u.netloc)!=(urlsplit(self.base_url).scheme,urlsplit(self.base_url).netloc):
            raise ValueError('Original is not on the configured archive')
        if u.query: raise ValueError('Parameterized artifact URL is unsupported')
        return self.get(u.path,binary=True)

def normalize(collection,listing,detail,base_url='http://127.0.0.1:8769'):
    facts={str(k):v for k,v in detail.get('facts',[]) if isinstance(k,str)}
    meta=detail.get('metadata') or {}; meta=meta if isinstance(meta,dict) else {}
    links=detail.get('links') or listing.get('links') or []
    source_url=detail.get('source_url') or listing.get('source_url') or facts.get('Source address') or ''
    if not source_url:
        source_url=next((x.get('url') for x in links if x.get('label','').lower() in ('source address','original address','official source') and str(x.get('url','')).startswith('http')),'')
    original=detail.get('original_url') or listing.get('original_url') or next((x.get('url') for x in links if str(x.get('url','')).startswith(('/supplement-files/','/files/'))),'')
    if original and original.startswith('/'): original=urljoin(base_url,original)
    texts=[];partial=bool(detail.get('text_truncated'))
    if isinstance(detail.get('text'),str) and detail['text'].strip(): texts.append(detail['text'])
    else:
        for section in detail.get('sections',[]):
            heading=section.get('heading','')
            if isinstance(section.get('text'),str) and re.search(r'extracted text|saved text|document text|full text|reading text',heading,re.I):
                texts.append(section['text']); partial|=bool(re.search(r'first\s+[\d,]+\s+of|truncat',heading,re.I))
    pages=[{'text':text,'kind':'text_segment','label':f'Text segment {i+1}'} for i,text in enumerate(texts) if text.strip()]
    r={'collection':collection,'source_id':str(listing['id']),'title':detail.get('title') or listing.get('title') or str(listing['id']),
       'jurisdiction':detail.get('state') or listing.get('state') or facts.get('State') or 'UNKNOWN',
       'kind':detail.get('kind') or listing.get('kind') or 'document','citation':meta.get('citation') or detail.get('citation') or '',
       'source_url':source_url,'original_url':original,'qualification':detail.get('qualification') or listing.get('quality') or 'Source snapshot. Verify edition and currency.',
       'captured_at':detail.get('captured_at'),'published_at':detail.get('published_at'),'effective_at':detail.get('effective_from'),
       'snapshot':meta.get('snapshot'),'partial':partial,'source_metadata':{'facts':facts,'reading_notes':detail.get('reading_notes',{}),'metadata':meta},
       'rights':detail.get('license_ref') or 'Retains source-specific terms; original archive unchanged',
       'archive_record_url':base_url+('/#record/'+str(listing['id']) if collection=='bulk-law' else '/#'+collection+'/'+str(listing['id']))}
    # Only explicit namespaces/native fields are connected. Generic docket_id,
    # court_id or company names do not establish a cross-source identity.
    mappings={
      'courtlistener_court_id':('courtlistener.court',r'[a-z0-9]{2,24}'),
      'courtlistener_docket_id':('courtlistener.docket',r'[0-9]+'),
      'cl_docket_id':('courtlistener.docket',r'[0-9]+'),
      'mdl_number':('jpml.mdl',r'[0-9]{1,6}'),
      'doi':('doi',r'10\.[0-9]{4,9}/[^\s]+'),
      'setid':('dailymed.setid',r'[0-9a-fA-F-]{36}'),
      'application_number':('fda.application',r'(?:NDA|ANDA|BLA)[0-9]{6}'),
    }
    entities={}
    for origin,obj in [('detail',detail),('metadata',meta)]:
        for field,(namespace,pattern) in mappings.items():
            value=str(obj.get(field,'')).strip()
            if value and re.fullmatch(pattern,value):
                if namespace in ('doi','dailymed.setid'):value=value.lower()
                entities[(namespace,value)]={'namespace':namespace,'id':value,'basis':f'Explicit {origin}.{field} in the retained source response'}
    r['entities']=list(entities.values())
    return r,pages

def sync(store,client,collection,max_records=250,max_seconds=120,refresh=False,extract_originals=False):
    if collection not in COLLECTIONS: raise ValueError('Collection not supported; Trellis is intentionally untouched')
    if not 1<=max_records<=100000 or max_seconds<=0: raise ValueError('Use positive, bounded record/time limits')
    title,hub,_,_=COLLECTIONS[collection]
    store.collection(collection,title,hub=hub)
    prior=next(c for c in store.health()['collections'] if c['id']==collection)
    cursor=json.loads(prior['cursor'] or '{"page":1,"offset":0}') if not refresh else {'page':1,'offset':0}
    mode='pdf-pages' if extract_originals else 'api-text'
    if cursor.get('mode','api-text')!=mode: cursor={'page':1,'offset':0}
    cursor['mode']=mode
    processed=0;started=time.monotonic();total=prior['expected'];status='partial'
    while processed<max_records and time.monotonic()-started<max_seconds:
        try:
            listing=client.listing(collection,cursor['page'],50)
            if listing.get('available') is False:
                reason=listing.get('reason','Source gate closed')
                store.collection(collection,title,status='unavailable',reason=reason)
                return {'status':'unavailable','reason':reason,'processed':processed}
            if 'error' in listing: raise ValueError('Archive search returned an error')
            total=listing.get('total',total)
            rows=listing.get('results',listing.get('items',[]))
            if not isinstance(rows,list): raise ValueError('Invalid archive listing shape')
            if not rows or cursor['offset']>=len(rows):
                if not rows: status='ready';break
                cursor={'page':cursor['page']+1,'offset':0,'mode':mode};continue
            for row in rows[cursor['offset']:]:
                if processed>=max_records or time.monotonic()-started>=max_seconds: break
                detail=client.detail(collection,row['id'])
                if not detail or detail.get('available') is False or 'error' in detail:
                    raise ValueError('Record unavailable; cursor retained for retry')
                record,pages=normalize(collection,row,detail,client.base_url)
                if extract_originals and record.get('original_url'):
                    data=client.original(record['original_url'])
                    if data.startswith(b'%PDF-'):
                        from .extraction import extract_pdf
                        with tempfile.TemporaryDirectory(prefix='corpus-native-') as d:
                            path=Path(d)/'source.pdf';path.write_bytes(data);extracted=extract_pdf(path)
                        record['partial']=extracted['partial'];record['extraction']=extracted['method'];record['needs_ocr']=extracted['needs_ocr'];record['original_sha256']=extracted['original_sha256'];pages=extracted['pages']
                result=store.ingest(record,pages);scan(store,result['version_id'])
                processed+=1;cursor['offset']+=1
                store.collection(collection,title,expected=total,status='partial',reason='',cursor=json.dumps(cursor),qualification=listing.get('qualification',''))
            if cursor['offset']>=len(rows): cursor={'page':cursor['page']+1,'offset':0,'mode':mode}
            # Do not call the next page when a bounded pass is already done.
        except Exception as error:
            store.collection(collection,title,expected=total,status='partial',reason=f'Import paused: {type(error).__name__}',cursor=json.dumps(cursor))
            return {'status':'paused','error':type(error).__name__,'message':str(error)[:200],'processed':processed,'cursor':cursor}
    store.collection(collection,title,expected=total,status=status,reason='',cursor=json.dumps(cursor))
    return {'status':status,'processed':processed,'source_total':total,'cursor':cursor,'originals_modified':False}

def import_jsonl(store,path):
    imported=0
    with Path(path).open(encoding='utf-8-sig') as f:
        for number,line in enumerate(f,1):
            if not line.strip(): continue
            try:
                data=json.loads(line);r=data['record'];pages=data.get('pages',[])
                store.collection(r['collection'],r.get('collection_title',r['collection']))
                result=store.ingest(r,pages);scan(store,result['version_id']); imported+=1
            except Exception as e: raise ValueError(f'JSONL row {number}: {e}') from e
    return {'imported':imported,'source_modified':False}
