import difflib

def compare(store,left,right,left_version=None,right_version=None,max_chars=120000):
    a=store.record(left,left_version); b=store.record(right,right_version)
    def body(r): return '\n\n'.join(p['text'] for p in r['pages'])
    ta,tb=body(a),body(b)
    diff='\n'.join(difflib.unified_diff(ta[:max_chars].splitlines(),tb[:max_chars].splitlines(),fromfile=a['title']+' / '+a['version_id'],tofile=b['title']+' / '+b['version_id'],lineterm=''))
    return {'left':{'id':a['id'],'version_id':a['version_id'],'title':a['title']},'right':{'id':b['id'],'version_id':b['version_id'],'title':b['title']},
            'diff':diff,'identical_text':ta==tb,'truncated':len(ta)>max_chars or len(tb)>max_chars,
            'qualification':'Mechanical saved-text comparison only. A difference is not a finding of legal effect, regulatory approval, or materiality.'}
