import unittest,tempfile,sqlite3
from pathlib import Path
from corpus_workbench.store import Store
class FinishTests(unittest.TestCase):
 def test_version_relationship_is_scoped(self):
  with tempfile.TemporaryDirectory() as d:
   s=Store(Path(d)/'work.db');s.collection('docs','Docs')
   def r(i,e):return s.ingest({'collection':'docs','source_id':i,'title':i,'entities':[{'namespace':'product','id':e,'basis':'source id'}]},[{'text':'Source'}])
   a=r('a','OLD');b=r('b','OLD');r('a','NEW')
   self.assertEqual(s.related(a['record_id'])['results'],[])
   self.assertEqual(s.related(a['record_id'],a['version_id'])['results'][0]['id'],b['record_id'])
 def test_other_version_one_database_refused(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'other.db';db=sqlite3.connect(p);db.execute('CREATE TABLE originals(x)');db.execute('PRAGMA user_version=1');db.commit();db.close();before=p.read_bytes()
   with self.assertRaises(ValueError):Store(p)
   self.assertEqual(before,p.read_bytes())
 def test_health_lists_actual_jurisdictions(self):
  with tempfile.TemporaryDirectory() as d:
   s=Store(Path(d)/'work.db');s.collection('docs','Docs');s.ingest({'collection':'docs','source_id':'x','title':'x','jurisdiction':'AL'},[{'text':'Source'}]);self.assertIn('AL',s.health()['jurisdictions'])
 def test_preview_is_selfcontained(self):
  from corpus_workbench.preview import build_preview
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'preview.html';build_preview(p);text=p.read_text();self.assertIn('WB_PREVIEW_API',text);self.assertNotIn('src="/static/',text);self.assertNotIn('href="/static/',text)
if __name__=='__main__':unittest.main()

class RefreshTests(unittest.TestCase):
 def test_health_counts_partial_text_separately(self):
  with tempfile.TemporaryDirectory() as d:
   s=Store(Path(d)/'work.db');s.collection('docs','Docs',expected=1)
   s.ingest({'collection':'docs','source_id':'x','title':'x','partial':True},[{'text':'First part'}])
   self.assertEqual(s.health()['partial_text'],1);self.assertEqual(s.health()['needs_recovery'],1)
 def test_paused_refresh_is_not_ready_from_counts(self):
  with tempfile.TemporaryDirectory() as d:
   s=Store(Path(d)/'work.db');s.collection('docs','Docs',expected=1);s.ingest({'collection':'docs','source_id':'x','title':'x'},[])
   s.collection('docs','Docs',status='partial',reason='Import paused: TimeoutError')
   self.assertEqual(s.health()['collections'][0]['status'],'partial')
 def test_switch_to_pdf_extraction_restarts_mode_cursor(self):
  from corpus_workbench.archive import sync
  class Fake:
   base_url='http://127.0.0.1:8769'
   def listing(self,c,page,limit):return {'available':True,'total':1,'results':[{'id':'a','title':'A'}] if page==1 else []}
   def detail(self,c,id):return {'title':'A','text':'text','original_url':'/files/a'}
   def original(self,url):self.calls+=1;return b'not pdf'
   calls=0
  with tempfile.TemporaryDirectory() as d:
   s=Store(Path(d)/'work.db');f=Fake();sync(s,f,'court-documents',10,10);sync(s,f,'court-documents',10,10,extract_originals=True)
   self.assertEqual(f.calls,1)

class IdentityTests(unittest.TestCase):
 def test_only_native_identifiers_become_relationships(self):
  from corpus_workbench.archive import normalize
  r,_=normalize('court-documents',{'id':'1'},{'title':'Order','metadata':{'courtlistener_court_id':'njd','courtlistener_docket_id':1234,'mdl_number':123,'sponsor_name':'ACME'}})
  links={e['namespace']:e['id'] for e in r.get('entities',[])}
  self.assertEqual(links.get('courtlistener.court'),'njd');self.assertEqual(links.get('courtlistener.docket'),'1234');self.assertNotIn('sponsor_name',links)
 def test_name_only_record_not_linked(self):
  from corpus_workbench.archive import normalize
  r,_=normalize('court-documents',{'id':'2'},{'title':'Order','metadata':{'judge_name':'Smith','company_name':'ACME'}})
  self.assertEqual(r.get('entities',[]),[])

class EnrichmentIdentityTests(unittest.TestCase):
 def test_label_import_uses_same_namespace_as_archive(self):
  import hashlib,json,zipfile,io
  from corpus_workbench.enrich import import_receipts
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);s=Store(root/'work.db');buf=io.BytesIO()
   with zipfile.ZipFile(buf,'w') as z:
    z.writestr('label.xml','<document xmlns="urn:hl7-org:v3"><section><title>Warnings</title><text>Saved labeling text.</text></section></document>')
   body=buf.getvalue();(root/'label.bin').write_bytes(body)
   setid='12345678-1234-1234-1234-123456789abc'
   receipt={'id':'label1','status':'saved','kind':'label','artifact':'label.bin','sha256':hashlib.sha256(body).hexdigest(),'source_id':'label1','url':'https://dailymed.nlm.nih.gov/label','captured_at':'2026-09-20T00:00:00Z','setid':setid}
   (root/'receipts.jsonl').write_text(json.dumps(receipt)+'\n')
   import_receipts(s,root)
   s.collection('archive-label','Archive label')
   a=s.ingest({'collection':'archive-label','source_id':'label2','title':'Another saved label','entities':[{'namespace':'dailymed.setid','id':setid,'basis':'Native SET ID'}]},[{'text':'Other text'}])
   self.assertEqual(len(s.related(a['record_id'])['results']),1)
