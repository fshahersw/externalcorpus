@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  python -m unittest discover -s tests -p "test_*.py" -v
) else (
  py -3 -m unittest discover -s tests -p "test_*.py" -v
)
if errorlevel 1 goto failed
where node >nul 2>nul
if errorlevel 1 goto nonode
node --test tests/receiver.test.mjs
if errorlevel 1 goto failed
:nonode
pause
exit /b 0
:failed
echo Verification failed. Do not deploy.
pause
exit /b 1
