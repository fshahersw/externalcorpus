"""Optional Playwright checks of the offline UI. No live corpus or internet calls."""
import json,sys
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from corpus_workbench.preview import build_preview
output=ROOT/'evidence';shots=output/'screenshots';shots.mkdir(parents=True,exist_ok=True)
preview=build_preview(output/'browser-preview.html').read_text()
checks=[];errors=[];network=[]
def check(test,name):
 checks.append({'check':name,'passed':bool(test)})
 if not test:raise AssertionError(name)
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for width in [1440,1024,390]:
  page=browser.new_page(viewport={'width':width,'height':1000 if width>400 else 844})
  page.set_default_timeout(6000)
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('request',lambda r:network.append(r.url))
  page.set_content(preview,wait_until='load')
  page.wait_for_selector('h1')
  def no_overflow(label):check(page.evaluate('document.documentElement.scrollWidth<=innerWidth'),f'{width} {label}: no page overflow')
  def goto(hash,expected):
   page.evaluate('(h)=>location.hash=h',hash);page.wait_for_function('(e)=>document.querySelector("h1")?.textContent===e',arg=expected);no_overflow(hash)
  check(page.locator('h1').inner_text()=='Your sources. Connected.',f'{width}: home rendered')
  check(page.locator('.stat').count()==4,f'{width}: status counts')
  no_overflow('home');page.screenshot(path=str(shots/f'home-{width}.png'),full_page=False)
  page.locator('#search-input').fill('expert');page.locator('#search-form button[type=submit]').click();page.wait_for_function('document.querySelector("h1")?.textContent.includes("expert")')
  check(page.locator('.result-row').count()>=2,f'{width}: word search');no_overflow('search')
  page.screenshot(path=str(shots/f'search-{width}.png'),full_page=False)
  first=page.locator('.result-row').first
  first.locator('[data-select]').click();page.wait_for_function('document.querySelector("#tray-count").textContent==="1"')
  check(True,f'{width}: selection')
  page.locator('.result-row').first.locator('[data-open]').first.click();page.wait_for_selector('.reader-head h2');check(page.locator('#shell').evaluate('(x)=>x.inert'),f'{width}: reader focus isolation')
  for tab in ['citations','related','versions','source','text']:
   page.locator(f'[data-reader-tab="{tab}"]').click();page.wait_for_timeout(80);check(page.locator(f'[data-reader-tab="{tab}"].active').count()==1,f'{width}: {tab} tab');no_overflow('reader '+tab)
  page.screenshot(path=str(shots/f'reader-{width}.png'),full_page=False)
  page.keyboard.press('Escape');check(page.locator('#reader').is_hidden(),f'{width}: escape closes reader')
  goto('#/collections','Browse collections');check(page.locator('.health-card').count()==6,f'{width}: source collections')
  goto('#/collections?hub=states','States & counties');check(page.locator('.health-card').count()==2,f'{width}: hub filter')
  goto('#/health','Source health');page.screenshot(path=str(shots/f'health-{width}.png'),full_page=False)
  goto('#/search?q=Alpha','Results for “Alpha”');page.locator('[data-open]').filter(has_text='Product Alpha — labeling history').first.click();page.wait_for_selector('.reader-head h2')
  page.locator('[data-reader-tab="versions"]').click();page.wait_for_selector('.version-item')
  check(page.locator('.version-item').count()==2,f'{width}: saved version history')
  page.screenshot(path=str(shots/f'versions-{width}.png'),full_page=False)
  page.locator('[data-compare-version]').click();page.wait_for_selector('.diff');check('Additional monitoring' in page.locator('.diff').inner_text(),f'{width}: compare real saved fixture versions');no_overflow('comparison')
  page.screenshot(path=str(shots/f'compare-{width}.png'),full_page=False);page.keyboard.press('Escape')
  goto('#/tray','Your evidence set');page.locator('[data-handoff]').click();page.wait_for_selector('.handoff-targets');check(page.locator('[data-target]').count()==3,f'{width}: three handoff destinations')
  check('Nothing is automatically submitted' in page.locator('.reader-body').inner_text(),f'{width}: handoff not falsely submitted')
  page.keyboard.press('Escape')
  goto('#/search?availability=metadata_only','Search your sources');check(page.locator('.result-row').count()==1,f'{width}: metadata-only filter')
  goto('#/search?availability=partial_text','Search your sources');page.wait_for_timeout(100);check(page.locator('.result-row').count()==1,f'{width}: partial-text filter')
  goto('#/search?q=nomatchxyz','Results for “nomatchxyz”');check(page.locator('.empty').count()>0,f'{width}: honest absent record state')
  if width==390:
   page.locator('#menu-toggle').click();check('open' in page.locator('#sidebar').get_attribute('class'),f'{width}: mobile navigation')
  page.close()
 browser.close()
check(not errors,'No page JavaScript exceptions')
check(not network,'No external or local network requests from offline preview')
report={'status':'passed','checks':len(checks),'results':checks,'errors':errors,'network':network,'scope':'Offline in-memory preview with synthetic fixtures. Actual loopback HTTP tested separately in test_http.py. Chromium policy blocks URL navigation; no policy was changed.'}
(output/'browser-verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'status':'passed','checks':len(checks),'errors':errors,'network_requests':len(network)}))
