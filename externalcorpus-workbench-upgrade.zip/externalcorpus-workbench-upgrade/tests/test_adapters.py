import unittest,tempfile,importlib.util,json,hashlib
from pathlib import Path

class AdapterTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(importlib.util.find_spec('corpus_workbench.archive'),'archive adapter must exist')
    def test_refuses_remote_archive(self):
        from corpus_workbench.archive import ArchiveClient
        for url in ('http://evil.example','file:///tmp/a','http://user:pass@127.0.0.1:8769','http://127.0.0.1:8769/path','http://127.0.0.1:8769?x=y'):
            with self.assertRaises(ValueError): ArchiveClient(url)
    def test_partial_detail(self):
        from corpus_workbench.archive import normalize
        r,p=normalize('agency-documents',{'id':'12','title':'Report'}, {'title':'Report','facts':[['Source address','https://www.fda.gov/report']], 'sections':[{'heading':'Extracted text (first 60,000 of 100,000 characters)','text':'Some extract'}], 'qualification':'Partial source'})
        self.assertTrue(r['partial']); self.assertEqual(p[0]['kind'],'text_segment')
        self.assertEqual(r['source_url'],'https://www.fda.gov/report')
        self.assertEqual(r['qualification'],'Partial source')
    def test_metadata_not_fabricated_as_text(self):
        from corpus_workbench.archive import normalize
        r,p=normalize('court-documents',{'id':'1','title':'Order'}, {'title':'Order','facts':[['File','order.pdf']],'sections':[]})
        self.assertEqual(p,[])
    def test_text_root_and_dates_preserved(self):
        from corpus_workbench.archive import normalize
        r,p=normalize('bulk-law',{'id':'oul:x','title':'Provision'}, {'title':'Provision','text':'Legal text','text_truncated':True,'metadata':{'citation':'Cal. CCP § 335.1','snapshot':'2026.08'},'source_url':'https://leginfo.legislature.ca.gov/x','reading_notes':{'currency_verified':False}})
        self.assertTrue(r['partial']); self.assertEqual(r['citation'],'Cal. CCP § 335.1'); self.assertIsNone(r.get('effective_at'))
    def test_resume_does_not_skip_midpage(self):
        from corpus_workbench.archive import sync
        from corpus_workbench.store import Store
        class Client:
            base_url='http://127.0.0.1:8769'
            def listing(self,c,page,limit): return {'available':True,'total':3,'results':[{'id':str(i),'title':str(i)} for i in range(3)]} if page==1 else {'available':True,'total':3,'results':[]}
            def detail(self,c,id): return {'title':id,'text':'Some source text'}
        with tempfile.TemporaryDirectory() as d:
            s=Store(Path(d)/'index.db'); a=sync(s,Client(),'court-documents',max_records=1)
            self.assertEqual(a['processed'],1)
            b=sync(s,Client(),'court-documents',max_records=3)
            self.assertEqual(s.health()['records'],3)
            self.assertEqual(b['processed'],2)
    def test_source_unavailable_not_empty(self):
        from corpus_workbench.archive import sync
        from corpus_workbench.store import Store
        class Client:
            base_url='http://127.0.0.1:8769'
            def listing(self,*a): return {'available':False,'reason':'hash mismatch'}
        with tempfile.TemporaryDirectory() as d:
            s=Store(Path(d)/'index.db'); r=sync(s,Client(),'court-documents')
            self.assertEqual(r['status'],'unavailable')
            self.assertIn('hash',s.health()['collections'][0]['reason'])
    def test_trellis_not_importable(self):
        from corpus_workbench.archive import sync
        from corpus_workbench.store import Store
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError): sync(Store(Path(d)/'index.db'),None,'trellis')
    def test_api_partial_withheld_not_indexed(self):
        from corpus_workbench.archive import normalize
        r,p=normalize('source-documents',{'id':'1','title':'Test'}, {'facts':[['Extracted text','Withheld: hash mismatch']],'sections':[]})
        self.assertEqual(p,[]); self.assertIn('Withheld',json.dumps(r))
    def test_native_pdf_keeps_original(self):
        from corpus_workbench.extraction import extract_pdf
        import fitz
        with tempfile.TemporaryDirectory() as d:
            src=Path(d)/'original.pdf'; doc=fitz.open(); p=doc.new_page(); p.insert_text((40,50),'Expert evidence on page one.'); doc.new_page(); doc.save(src); doc.close()
            before=src.read_bytes(); r=extract_pdf(src)
            self.assertEqual(src.read_bytes(),before); self.assertEqual(len(r['pages']),2)
            self.assertEqual(r['pages'][0]['kind'],'pdf_page'); self.assertTrue(r['partial']); self.assertEqual(r['needs_ocr'],[2])
    def test_jsonl_import_schema(self):
        from corpus_workbench.archive import import_jsonl
        from corpus_workbench.store import Store
        with tempfile.TemporaryDirectory() as d:
            source=Path(d)/'input.jsonl'; source.write_text(json.dumps({'record':{'collection':'official','source_id':'a','title':'A'},'pages':[{'text':'Example','kind':'section','label':'§ 1'}]})+'\n')
            s=Store(Path(d)/'index.db'); result=import_jsonl(s,source)
            self.assertEqual(result['imported'],1); self.assertEqual(s.search('Example')['total'],1)
    def test_compare_versions(self):
        from corpus_workbench.compare import compare
        from corpus_workbench.store import Store
        with tempfile.TemporaryDirectory() as d:
            s=Store(Path(d)/'index.db');s.collection('law','Law')
            a=s.ingest({'collection':'law','source_id':'a','title':'Provision'},[{'text':'Old warning.'}]);b=s.ingest({'collection':'law','source_id':'a','title':'Provision'},[{'text':'New warning.'}])
            r=compare(s,a['record_id'],b['record_id'],a['version_id'],b['version_id'])
            self.assertIn('-Old warning.',r['diff']); self.assertIn('+New warning.',r['diff'])
    def test_safe_request_url(self):
        from corpus_workbench.enrich import allowed_url
        for url in ['http://www.fda.gov/a','https://www.fda.gov.evil.test/a','https://127.0.0.1/a','https://user:pass@www.fda.gov/a','https://www.fda.gov:444/a']:
            with self.assertRaises(ValueError): allowed_url(url)
        self.assertEqual(allowed_url('https://www.fda.gov/a'),'https://www.fda.gov/a')
    def test_label_history_preserves_dates(self):
        from corpus_workbench.enrich import label_history_jobs
        data={'data':{'spls':[{'spl_version':'1','published_date':'Jan 01, 2020'},{'spl_version':'2','published_date':'not known'}]}}
        jobs=label_history_jobs('11111111-1111-4111-8111-111111111111',data)
        self.assertEqual(len(jobs),2); self.assertEqual(jobs[0]['published_at'],'2020-01-01')
        self.assertIsNone(jobs[1]['published_at']); self.assertEqual(jobs[1]['published_date_raw'],'not known')
    def test_enrichment_plan_requires_explicit_url(self):
        from corpus_workbench.enrich import plan_jobs
        jobs=plan_jobs([{'source_id':'x','title':'Firm warning letter','source_url':'https://www.fda.gov/warning-letters/x'}],'warning-letter')
        self.assertEqual(jobs[0]['status'],'planned')
        with self.assertRaises(ValueError): plan_jobs([{'source_id':'x','title':'No URL'}],'warning-letter')

if __name__=='__main__':unittest.main()
