import unittest,tempfile,json,zipfile,io
from pathlib import Path
from corpus_workbench.store import Store
from corpus_workbench.citations import scan
class EnrichmentTests(unittest.TestCase):
 def test_real_dailymed_history_shape(self):
  from corpus_workbench.enrich import label_history_jobs
  r=label_history_jobs('11111111-1111-4111-8111-111111111111',{'metadata':{'next_page':'null'},'data':{'history':[{'spl_version':'3','published_date':'Sep 26, 2012'}]}})
  self.assertEqual(len(r),1);self.assertIn('version=3',r[0]['url'])
 def test_cited_by_saved_law(self):
  with tempfile.TemporaryDirectory() as d:
   s=Store(Path(d)/'i.db');s.collection('law','Law');s.collection('docs','Docs')
   s.ingest({'collection':'law','source_id':'law','title':'Provision','citation':'28 USC 1332'},[{'text':'Sample provision'}])
   r=s.ingest({'collection':'docs','source_id':'motion','title':'Motion'},[{'text':'This cites 28 U.S.C. § 1332.'}]);scan(s,r['version_id'])
   self.assertTrue(hasattr(s,'cited_by'),'Inbound citations must be available')
   self.assertEqual(s.cited_by('28 USC 1332')['total'],1)
 def test_spl_zip_sections(self):
  from corpus_workbench.enrich import spl_sections
  b=io.BytesIO()
  with zipfile.ZipFile(b,'w') as z:z.writestr('label.xml','<document xmlns="urn:hl7-org:v3"><component><section><title>Warnings</title><text><paragraph>Sample warning.</paragraph></text></section></component></document>')
  r=spl_sections(b.getvalue());self.assertEqual(r[0]['label'],'Warnings');self.assertIn('Sample warning.',r[0]['text'])
 def test_spl_rejects_dtd(self):
  from corpus_workbench.enrich import spl_sections
  b=io.BytesIO()
  with zipfile.ZipFile(b,'w') as z:z.writestr('label.xml','<!DOCTYPE x [<!ENTITY secret SYSTEM "file:///etc/passwd">]><x>&secret;</x>')
  with self.assertRaises(ValueError):spl_sections(b.getvalue())
 def test_untrusted_database_refused(self):
  import sqlite3
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'original.sqlite3';db=sqlite3.connect(p);db.execute('CREATE TABLE originals(a)');db.close()
   before=p.read_bytes()
   with self.assertRaises(ValueError):Store(p)
   self.assertEqual(p.read_bytes(),before)
 def test_compare_does_not_claim_legal_effect(self):
  from corpus_workbench.compare import compare
  with tempfile.TemporaryDirectory() as d:
   s=Store(Path(d)/'i.db');s.collection('law','Law')
   a=s.ingest({'collection':'law','source_id':'a','title':'v1'},[{'text':'A'}]);b=s.ingest({'collection':'law','source_id':'b','title':'v2'},[{'text':'B'}])
   self.assertIn('not a finding of legal effect',compare(s,a['record_id'],b['record_id'])['qualification'])
if __name__=='__main__':unittest.main()
