"""Explicit synthetic fixtures. Never automatically mixed into imported live data."""
from .citations import scan
SOURCES=[('court-documents','Court documents','courts'),('law','Saved law','states'),('agency-documents','Agency & science','federal'),('source-documents','Source documents','federal'),('saved-pages','Rules & filing guides','states'),('uscourts','U.S. Courts publications','courts')]
DOCS=[
('law','ca-335','Civil procedure — limitations research starting point','CA','statute','Cal. CCP § 335.1','Illustrative provision for interface testing. This is not the wording of any statute. Verify current law and the applicable edition before relying on a limitation period.'),
('law','usc-1332','Federal jurisdiction — saved provision','FEDERAL','statute','28 U.S.C. § 1332','Illustrative saved provision. The interface connects exact citation references without deciding jurisdiction or applicability.'),
('court-documents','expert-motion','Expert testimony — methodology challenge','NJ','motion','','Illustrative expert motion. Review the witness methodology and the basis of each opinion. This source cites 28 U.S.C. § 1332. A citation link does not establish that the source supports the proposition.'),
('court-documents','expert-order','Expert testimony — hearing preparation','NJ','order','','Illustrative court document. Counsel should prepare questions about expert reliability and the analysis underlying the opinions. The saved source refers to 28 U.S.C. § 1332. This is fictional sample text.'),
('court-documents','case-management','Case management — document production','CA','case management order','','Illustrative case-management order. Organize document production by source, date and custodian. Preserve the original source and exact page locations. See Cal. CCP § 335.1 in this demonstration.'),
('court-documents','standing-order','Standing order — motion practice','IL','standing order','','Illustrative standing order. Motion-practice requirements must be verified against the actual court and current version. This sample demonstrates a saved original with page-level text.'),
('agency-documents','alpha-label','Product Alpha — labeling history','FEDERAL','label','','ILLUSTRATIVE LABEL VERSION 1\n\nWarnings and precautions\nReview the original labeling and supporting safety information. Preserve the date and edition used in every comparison.'),
('agency-documents','alpha-safety','Product Alpha — safety communication','FEDERAL','safety communication','','Illustrative safety communication for Product Alpha. Connect the product using its publisher identifier, not simply its brand spelling. This sample does not describe a real product or establish causation.'),
('agency-documents','risk-methods','Exposure assessment — source methodology','FEDERAL','science report','','Illustrative source-methodology report. Separate exposure, outcome, confounding and study limitations. Use source evidence to describe findings rather than inferring legal causation.'),
('source-documents','consent-agreement','Consumer protection — consent agreement','NY','consent agreement','','Illustrative consent agreement. Obligations, dates and parties should be extracted from the agreement itself, not inferred from the announcement. Keep the original document and extracted fields linked.'),
('source-documents','warning-letter','Manufacturer review — warning letter','FEDERAL','warning letter','','Illustrative warning letter. Review the manufacturer response, inspection observations and corrective actions. A warning letter is a source record, not by itself a finding of civil liability.'),
('saved-pages','filing-guide','Court filing and motion-practice guide','IL','filing guide','','Illustrative filing guide. Confirm the court, procedure and relevant date. Statewide instructions are not automatically local rules for every county.'),
('saved-pages','local-rules','Local rules — research checklist','NJ','local rule','','Illustrative local-rule checklist. Keep the local rule, applicable standing orders and any case-specific directions separate. This source should not be treated as complete coverage.'),
('uscourts','statistics','Court statistics — source methodology','FEDERAL','statistical methodology','','Illustrative statistics reference. Counts reflect the selected collection and measurement period, not a prediction of judicial behavior.'),
('court-documents','scan-gap','Scanned exhibit — awaiting text recovery','CA','exhibit','',''),
]
def seed(store):
 if store.health()['records']: raise ValueError('Demo seed requires an empty demo database; never mixes with real records')
 for id,title,hub in SOURCES: store.collection(id,title,hub=hub)
 for c,sid,title,jur,kind,cite,text in DOCS:
  r={'collection':c,'source_id':sid,'title':title,'jurisdiction':jur,'kind':kind,'citation':cite,'source_url':'https://example.invalid/'+sid,
     'qualification':'Illustrative preview record only. Not a real legal source or finding.','snapshot':'Demonstration snapshot','demo':True}
  if sid in ('alpha-label','alpha-safety'):r['entities']=[{'namespace':'demo_product','id':'ALPHA-001','label':'Product Alpha','basis':'Explicit shared fixture identifier'}]
  pages=[{'label':'Page 1','kind':'pdf_page','text':text}] if text else []
  a=store.ingest(r,pages);scan(store,a['version_id'])
  if sid=='alpha-label':
   r['snapshot']='Demonstration version 2'
   b=store.ingest(r,[{'label':'Page 1','kind':'pdf_page','text':text.replace('VERSION 1','VERSION 2')+'\n\nAdditional monitoring\nA new illustrative section is included in this version for comparison testing.'}]);scan(store,b['version_id'])
 # A partial extraction has at least one empty physical page.
 a=store.ingest({'collection':'court-documents','source_id':'partial-exhibit','title':'Technical exhibit — partial extraction','jurisdiction':'TX','kind':'exhibit','demo':True,'qualification':'Illustrative: page 2 requires OCR.'},[{'label':'Page 1','kind':'pdf_page','text':'Illustrative exhibit with readable first-page text about expert methods.'},{'label':'Page 2','kind':'pdf_page','text':''}]);scan(store,a['version_id'])
 for c in store.health()['collections']:store.collection(c['id'],c['title'],expected=c['indexed'])
 return store.health()
