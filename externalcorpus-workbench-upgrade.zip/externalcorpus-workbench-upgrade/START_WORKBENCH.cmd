@echo off
setlocal
cd /d "%~dp0"
echo Corpus Workbench: original archive and Trellis are not modified.
echo Import data with the sync command in README.md before using real search.
where py >nul 2>nul
if errorlevel 1 (
  python -m corpus_workbench serve --open
) else (
  py -3 -m corpus_workbench serve --open
)
if errorlevel 1 pause
