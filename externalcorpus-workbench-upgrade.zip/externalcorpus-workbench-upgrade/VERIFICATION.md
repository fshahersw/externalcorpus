# Verification record

Verified September 20, 2026 in the working container.

| Check | Fresh result |
|---|---|
| Python backend / import / enrichment / HTTP regressions | 65 tests passed, no skips |
| JavaScript application receiver | 8 tests passed |
| Interactive browser regression suite | 111 assertions passed at 1440, 1024, and 390 px |
| Browser uncaught JavaScript errors | 0 |
| Offline-preview external / local network requests | 0 |
| Python compilation | Passed |
| App and preview JavaScript syntax checks | Passed |

Commands and complete results are included in `evidence/final-python.log`, `evidence/final-receiver.log`, `evidence/final-browser.log`, and `evidence/browser-verification.json`.

The Python tests exercise actual temporary SQLite databases, fixture imports and extraction, and a real loopback HTTP listener. External acquisition uses fixtures; it was not run against FDA, NAAG, DailyMed, or CourtListener. Tests ran with pypdf 5.9.0 and without eyecite, so the limited built-in citation detector is the tested detector. Optional eyecite and OCRmyPDF need separate validation on the target machine.

The browser tests use explicit synthetic records and in-memory responses inside the offline preview. They are not a browser test of your restored corpus or production site. Existing screenshots from the interrupted attempt are not used as verification; screenshots shipped here were freshly rendered from this package.

No full-corpus restore, corpus-wide PDF extraction, remote enrichment, Windows launcher execution, production auth integration, deployment, GitHub commit, release edit, or original-data modification was performed. This package adds a separate UI and sidecar; it does not patch the original application's search route. That original interface keeps its old behavior.
