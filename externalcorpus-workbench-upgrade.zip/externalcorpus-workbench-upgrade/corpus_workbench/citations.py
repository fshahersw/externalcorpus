"""Page-anchored citations; detection/resolution is not a good-law assessment."""
import re, json

PARSER_VERSION='workbench-citations-1.0'
QUALIFICATION='Citation detected in saved text; not an assessment of support, treatment, legal validity, or current law.'
FED=r'\b\d{1,3}\s+(?:U\.?\s*S\.?\s*C\.?|C\.?\s*F\.?\s*R\.?)\s*(?:§{1,2}\s*)?\d+[A-Za-z]*(?:[-.]\d+[A-Za-z]*)*(?:\([A-Za-z0-9]+\))*'
STATE=r'(?:Cal\.\s*(?:CCP|Civ\.\s*Code|Code\s+Civ\.\s*Proc\.)|N\.?J\.?S\.?A\.?|N\.?Y\.?\s*CVP\s*Law|Tex\.\s*Civil\s*Practice\s*and\s*Remedies\s*Code|\d+\s*ILCS)\s*(?:§\s*)?[\dA-Za-z]+(?:[.:/-][\dA-Za-z]+)*(?:\([A-Za-z0-9]+\))*'
CASE=r'\b\d+\s+(?:U\.\s*S\.|S\.\s*Ct\.|F\.\s*(?:Supp\.\s*(?:2d|3d)?|2d|3d|4th|App\x27x))\s+\d+'
PATTERN=re.compile('(?:'+FED+'|'+STATE+'|'+CASE+')',re.I)

def canonical(value):
    s=str(value or '').strip()
    # Edition is kept in the source metadata, never silently used as an applicability date.
    s=re.sub(r'\s*\((?:19|20)\d{2}\)\s*$','',s)
    s=re.sub(r'\bU\.?\s*S\.?\s*C\.?', 'USC',s,flags=re.I)
    s=re.sub(r'\bC\.?\s*F\.?\s*R\.?', 'CFR',s,flags=re.I)
    s=re.sub(r'\bCal\.\s*Code\s+Civ\.\s*Proc\.', 'Cal. CCP',s,flags=re.I)
    s=s.replace('§','').replace('–','-').replace('—','-')
    return re.sub(r'\s+','',s).casefold().rstrip('.,;')

def detect(text):
    found=[]
    # The optional library increases recall; a limited deterministic fallback is
    # explicitly reported, rather than pretending to resolve every citation style.
    try:
        from eyecite import get_citations
        from eyecite.models import FullCaseCitation,FullLawCitation,FullJournalCitation
    except ImportError:
        get_citations=None
    if get_citations:
        for cite in get_citations(text):
            if not isinstance(cite,(FullCaseCitation,FullLawCitation,FullJournalCitation)): continue
            start,end=cite.span(); raw=text[start:end]
            kind='case' if isinstance(cite,FullCaseCitation) else 'journal' if isinstance(cite,FullJournalCitation) else 'law'
            found.append({'raw':raw,'key':canonical(raw),'kind':kind,'start':start,'end':end})
    else:
        for m in PATTERN.finditer(text):
            raw=m.group().strip().rstrip('.,;')
            kind='case' if re.fullmatch(CASE,raw,re.I) else 'law'
            found.append({'raw':raw,'key':canonical(raw),'kind':kind,'start':m.start(),'end':m.start()+len(raw)})
    return found

def effective_version():
    try:
        import importlib.metadata
        version=importlib.metadata.version('eyecite')
        return PARSER_VERSION+'/eyecite-'+version
    except importlib.metadata.PackageNotFoundError:
        return PARSER_VERSION+'/limited-regex'

def scan(store,version_id,parser=None,parser_version=None):
    parser=parser or detect
    signature=parser_version or effective_version()
    with store.connect() as db:
        v=db.execute('SELECT * FROM versions WHERE id=?',(version_id,)).fetchone()
        if not v: raise KeyError('Unknown document version')
        if v['scan_status']=='scanned' and v['scan_version']==signature:
            return {'status':'scanned','skipped':True,'parser_version':signature}
        pages=db.execute('SELECT * FROM pages WHERE version_id=? ORDER BY page_index',(version_id,)).fetchall()
    try:
        rows=[]
        for p in pages:
            for c in parser(p['text']):
                start,end=int(c['start']),int(c['end'])
                if not 0<=start<end<=len(p['text']): raise ValueError('Citation location outside source text')
                rows.append((version_id,c['key'],c['raw'],c['kind'],p['page_index'],start,end,p['text'][max(0,start-160):end+160]))
        with store.connect(write=True) as db:
            db.execute('DELETE FROM citations WHERE version_id=?',(version_id,))
            db.executemany('INSERT INTO citations(version_id,authority_key,raw,kind,page_index,start_offset,end_offset,passage) VALUES(?,?,?,?,?,?,?,?)',rows)
            db.execute("UPDATE versions SET scan_status='scanned',scan_version=?,scan_error=NULL WHERE id=?",(signature,version_id))
        return {'status':'scanned','skipped':False,'mentions':len(rows),'parser_version':signature,'qualification':QUALIFICATION}
    except Exception as error:
        with store.connect(write=True) as db:
            # Old rows are preserved for diagnostics but hidden while scan_status!=scanned.
            db.execute("UPDATE versions SET scan_status='failed',scan_version=?,scan_error=? WHERE id=?",(signature,type(error).__name__,version_id))
        return {'status':'failed','skipped':False,'error':type(error).__name__,'parser_version':signature}
