"""Native PDF extraction first. OCR is optional and always a separate derivative."""
import hashlib,shutil,subprocess,tempfile
from pathlib import Path

def extract_pdf(path,max_pages=3000):
    path=Path(path).resolve()
    if not path.is_file() or path.stat().st_size>150*1024*1024: raise ValueError('PDF missing or larger than 150 MB processing bound')
    from pypdf import PdfReader
    reader=PdfReader(path)
    if reader.is_encrypted and not reader.decrypt(''): raise ValueError('Encrypted PDF requires authorized decryption')
    pages=[];needs_ocr=[];failed=[]
    for index,page in enumerate(reader.pages):
        if index>=max_pages: break
        try: text=page.extract_text() or ''
        except Exception: text='';failed.append(index+1)
        if not text.strip(): needs_ocr.append(index+1)
        pages.append({'label':f'Page {index+1}','kind':'pdf_page','text':text})
    sha=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): sha.update(chunk)
    return {'pages':pages,'total_pages':len(reader.pages),'extracted_pages':len(pages),'partial':bool(needs_ocr or failed or len(pages)<len(reader.pages)),
            'needs_ocr':needs_ocr,'failed_pages':failed,'method':'pypdf native text','original_sha256':sha.hexdigest(),
            'qualification':'PDF page numbers refer to physical file pages, not necessarily printed page labels. Native text quality is not independently verified.'}

def ocr_derivative(source,output_directory,timeout=1800):
    """Explicit CLI use only; optional OCRmyPDF installation. Never overwrite input."""
    source=Path(source).resolve();output=Path(output_directory).resolve()
    executable=shutil.which('ocrmypdf')
    if not executable: raise RuntimeError('OCRmyPDF is not installed. Native extraction remains available; OCR-needed pages are queued.')
    output.mkdir(parents=True,exist_ok=True)
    target=output/(source.stem+'.ocr.pdf')
    if target==source or target.exists(): raise ValueError('OCR output must be a new derivative file')
    subprocess.run([executable,'--skip-text','--output-type','pdf','--quiet',str(source),str(target)],check=True,timeout=timeout)
    return target
