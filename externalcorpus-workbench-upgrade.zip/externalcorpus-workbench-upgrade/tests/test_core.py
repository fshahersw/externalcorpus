import unittest, tempfile, importlib.util, json, sqlite3
from pathlib import Path

class CoreTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(importlib.util.find_spec('corpus_workbench.store'), 'versioned evidence store must be implemented')
        from corpus_workbench.store import Store
        self.tmp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.tmp.name)/'evidence.sqlite3')
        self.store.collection('court-documents', 'Court documents', hub='courts', expected=3)
        self.store.collection('law', 'Saved law', hub='states', expected=1)
    def tearDown(self):
        if hasattr(self,'tmp'): self.tmp.cleanup()
    def add(self, id='a', text='Expert testimony requires reliable methods. See 28 U.S.C. § 1332.', **kw):
        rec={'collection':'court-documents','source_id':id,'title':'Expert testimony order','jurisdiction':'NJ','kind':'order','source_url':'https://example.gov/order','qualification':'Saved snapshot; verify current status', **kw}
        return self.store.ingest(rec,[{'label':'Page 1','kind':'pdf_page','text':text}])
    def test_all_words_not_phrase(self):
        self.add(text='Expert witnesses provide testimony using reliable methods.',title='Order')
        self.assertEqual(self.store.search('expert testimony')['total'],1)
        self.assertEqual(self.store.search('"expert testimony"')['total'],0)
    def test_any_words(self):
        self.add(text='expert methodology',title='Order')
        self.assertEqual(self.store.search('expert testimony',match='any')['total'],1)
        self.assertEqual(self.store.search('expert testimony',match='all')['total'],0)
    def test_query_is_inert(self):
        self.add()
        for q in ['"','***',"x'; DROP TABLE records;--",'NEAR(foo, bar)', '<script>alert(1)</script>']:
            self.store.search(q)
        self.assertEqual(self.store.search('')['total'],1)
    def test_filters(self):
        self.add()
        self.assertEqual(self.store.search('',jurisdiction='CA')['total'],0)
        self.assertEqual(self.store.search('',collection='court-documents')['total'],1)
        with self.assertRaises(ValueError): self.store.search('',unknown_filter='x')
    def test_bad_pagination(self):
        for args in [{'page':0},{'limit':101},{'page':'wat'}]:
            with self.assertRaises(ValueError): self.store.search('',**args)
    def test_versions_immutable(self):
        first=self.add(text='Old expert rule')
        second=self.add(text='New expert rule')
        self.assertNotEqual(first['version_id'],second['version_id'])
        self.assertEqual(len(self.store.versions(first['record_id'])),2)
        self.assertIn('Old expert',self.store.record(first['record_id'],first['version_id'])['pages'][0]['text'])
        self.assertEqual(self.store.search('old')['total'],0)
    def test_idempotent(self):
        a=self.add(); b=self.add()
        self.assertEqual(a['version_id'],b['version_id'])
        self.assertFalse(b['changed'])
        self.assertEqual(len(self.store.versions(a['record_id'])),1)
    def test_metadata_change_versioned(self):
        a=self.add(title='First'); b=self.add(title='Corrected title')
        self.assertNotEqual(a['version_id'],b['version_id'])
    def test_metadata_only(self):
        r=self.add(text='',title='Unextracted expert report')
        out=self.store.search('expert')
        self.assertEqual(out['total'],1)
        self.assertEqual(out['results'][0]['availability'],'metadata_only')
        self.assertIsNone(out['results'][0]['passage'])
    def test_partial_text_is_partial(self):
        a=self.add(text='Some extracted text',partial=True)
        self.assertEqual(self.store.record(a['record_id'])['availability'],'partial_text')
    def test_stable_pagination(self):
        for i in range(23): self.add(id=str(i),text=f'expert witness evidence {i}')
        pages=[self.store.search('expert',limit=10,page=i) for i in range(1,4)]
        ids=[r['id'] for p in pages for r in p['results']]
        self.assertEqual(len(ids),23); self.assertEqual(len(set(ids)),23)
        self.assertEqual(pages[0]['total'],23); self.assertFalse(pages[-1]['has_more'])
    def test_citation_total_over_eighty(self):
        from corpus_workbench.citations import scan
        r=self.add(text=' '.join(f'28 U.S.C. § {i}.' for i in range(1,96)))
        scan(self.store,r['version_id'])
        out=self.store.citations(r['record_id'],page=1,limit=80)
        self.assertEqual(out['total'],95); self.assertEqual(out['returned'],80); self.assertTrue(out['has_more'])
        self.assertEqual(self.store.citations(r['record_id'],page=2,limit=80)['returned'],15)
    def test_scan_resume_failure_and_parser_change(self):
        from corpus_workbench.citations import scan
        r=self.add()
        def broken(p): raise RuntimeError('bad parser')
        self.assertEqual(scan(self.store,r['version_id'],parser=broken,parser_version='x')['status'],'failed')
        self.assertEqual(scan(self.store,r['version_id'])['status'],'scanned')
        self.assertTrue(scan(self.store,r['version_id'])['skipped'])
        self.assertFalse(scan(self.store,r['version_id'],parser_version='next')['skipped'])
        self.assertEqual(self.store.citations(r['record_id'])['total'],1)
    def test_local_resolution_ambiguous(self):
        for i in ('edition1','edition2'):
            self.store.ingest({'collection':'law','source_id':i,'title':i,'citation':'28 U.S.C. § 1332','jurisdiction':'FEDERAL'},[{'text':'Diversity provision'}])
        resolved=self.store.resolve('28 USC 1332')
        self.assertEqual(resolved['status'],'ambiguous')
        self.assertEqual(len(resolved['candidates']),2)
        self.assertEqual(self.store.resolve('28 USC 99999')['status'],'unresolved')
    def test_state_resolution(self):
        self.store.ingest({'collection':'law','source_id':'ca','title':'Saved provision','citation':'Cal. CCP § 335.1','jurisdiction':'CA'},[{'text':'Illustrative provision'}])
        self.assertEqual(self.store.resolve('Cal. CCP § 335.1')['status'],'matched')
        self.assertEqual(self.store.resolve('Cal. CCP § 335.1(a)')['status'],'unresolved')
    def test_relations_are_evidence_based(self):
        from corpus_workbench.citations import scan
        a=self.add(id='a'); b=self.add(id='b',title='Another order')
        scan(self.store,a['version_id']); scan(self.store,b['version_id'])
        out=self.store.related(a['record_id'])
        self.assertEqual(out['results'][0]['id'],b['record_id'])
        self.assertEqual(out['results'][0]['basis'],'Shared cited authority')
    def test_entity_identifiers_not_names(self):
        entity={'namespace':'fda_application','id':'NDA123','label':'Sample product','basis':'Publisher application number'}
        a=self.add(id='a',entities=[entity]); b=self.add(id='b',entities=[entity]); self.add(id='c',title='Sample product')
        related=self.store.related(a['record_id'])['results']
        self.assertEqual({r['id'] for r in related},{b['record_id']})
    def test_handoff_preserves_evidence(self):
        a=self.add(); package=self.store.handoff([{'id':a['record_id'],'version_id':a['version_id']}],target='research')
        self.assertEqual(package['records'][0]['qualification'],'Saved snapshot; verify current status')
        self.assertEqual(package['records'][0]['version_id'],a['version_id'])
        self.assertFalse(package['submitted'])
        with self.assertRaises(KeyError): self.store.handoff([{'id':'fake'}])
    def test_coverage_distinguishes_pending(self):
        self.add()
        c={c['id']:c for c in self.store.health()['collections']}
        self.assertEqual(c['court-documents']['indexed'],1)
        self.assertEqual(c['law']['indexed'],0)
        self.assertEqual(c['court-documents']['status'],'partial')
    def test_blocked_collection_fail_closed(self):
        self.add(); self.store.collection('court-documents','Court documents',status='unavailable',reason='hash mismatch')
        self.assertEqual(self.store.search('expert')['total'],0)
        self.assertEqual(self.store.health()['collections'][0]['reason'],'hash mismatch')
    def test_safe_original_url(self):
        with self.assertRaises(ValueError): self.add(source_url='javascript:alert(1)')
    def test_canonical_citation_forms(self):
        from corpus_workbench.citations import canonical
        self.assertEqual(canonical('28 U.S.C. § 1332'),canonical('28 USC 1332'))
        self.assertNotEqual(canonical('28 USC 1332'),canonical('28 USC 1332(a)'))
    def test_text_change_invalidates_current_citations(self):
        from corpus_workbench.citations import scan
        a=self.add(); scan(self.store,a['version_id'])
        b=self.add(text='No citations in new content.')
        scan(self.store,b['version_id'])
        self.assertEqual(self.store.citations(b['record_id'])['total'],0)
        self.assertEqual(self.store.citations(a['record_id'],version_id=a['version_id'])['total'],1)

if __name__=='__main__': unittest.main()
