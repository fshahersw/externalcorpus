"""Explicit, bounded public-source jobs. No implicit crawling, account use, or paid APIs."""
import json,hashlib,re,time,uuid,zipfile,io
from pathlib import Path
from datetime import datetime,timezone
from urllib.parse import urlsplit,urlencode
from urllib.request import Request,build_opener,HTTPRedirectHandler
from urllib.robotparser import RobotFileParser
from urllib.error import HTTPError

HOSTS={'www.fda.gov','www.accessdata.fda.gov','dailymed.nlm.nih.gov','www.naag.org','naag.org','www.courtlistener.com'}
UA='CorpusWorkbench/1.0 (bounded public-source research)'

def allowed_url(url):
    if not isinstance(url,str): raise ValueError('An explicit source URL is required')
    u=urlsplit(url)
    if u.scheme!='https' or u.hostname not in HOSTS or u.username or u.password or u.port not in (None,443) or '\\' in url:
        raise ValueError('Only allowlisted HTTPS source URLs without credentials or custom ports are accepted')
    return url

class SourceRedirect(HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        allowed_url(newurl)
        # Per-request authorization and robots coverage must be reevaluated by caller.
        if urlsplit(req.full_url).hostname!=urlsplit(newurl).hostname: raise ValueError('Cross-host redirect requires a separately reviewed URL')
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def plan_jobs(records,kind):
    if kind not in ('warning-letter','settlement','opinion','label'): raise ValueError('Unsupported enrichment type')
    out=[]
    for r in records:
        url=allowed_url(r.get('source_url'))
        out.append({'id':hashlib.sha256((kind+'\0'+url).encode()).hexdigest()[:24],'kind':kind,'source_id':str(r.get('source_id') or url),
                    'title':r.get('title') or url,'url':url,'status':'planned','qualification':'Explicit URL only; identity and completeness are not inferred from a title.'})
    return out

def label_history_jobs(setid,data):
    setid=str(uuid.UUID(setid))
    payload=data.get('data') or {}; rows=payload.get('history',payload.get('spls',[])) if isinstance(payload,dict) else payload
    out=[]
    for r in rows:
        version=str(r.get('spl_version',''))
        if not version.isdigit(): continue
        raw=r.get('published_date'); published=None
        for fmt in ('%b %d, %Y','%B %d, %Y','%Y-%m-%d'):
            try: published=datetime.strptime(raw,fmt).date().isoformat();break
            except (ValueError,TypeError): pass
        url='https://dailymed.nlm.nih.gov/dailymed/getFile.cfm?'+urlencode({'type':'zip','setid':setid,'version':version})
        out.append({'id':setid+'-'+version,'kind':'label','source_id':setid+':'+version,'title':f'Label {setid} · version {version}','url':url,
                    'setid':setid,'spl_version':version,'published_at':published,'published_date_raw':raw,'status':'planned',
                    'qualification':'DailyMed publication history, not a regulatory approval or legal effective date.'})
    return out

def fetch_job(job,output_dir,max_bytes=50*1024*1024):
    """One request (plus robots), with receipts and no automatic retries."""
    url=allowed_url(job['url']);root=Path(output_dir).resolve();root.mkdir(parents=True,exist_ok=True)
    opener=build_opener(SourceRedirect());host=urlsplit(url).hostname
    rp=RobotFileParser();robots_url='https://'+host+'/robots.txt'
    try:
        with opener.open(Request(robots_url,headers={'User-Agent':UA}),timeout=20) as r: rp.parse(r.read(1024*1024).decode('utf-8','replace').splitlines())
    except HTTPError as e:
        if e.code not in (404,410): raise RuntimeError(f'Robots status {e.code}; job held') from e
        rp.parse([])
    except Exception as e: raise RuntimeError('Robots verification unavailable; job held') from e
    if not rp.can_fetch(UA,url): raise RuntimeError('Source robots policy disallows this URL; job held')
    delay=max(2,rp.crawl_delay(UA) or rp.crawl_delay('*') or 0)
    time.sleep(delay)
    timestamp=datetime.now(timezone.utc).isoformat()
    with opener.open(Request(url,headers={'User-Agent':UA}),timeout=45) as response:
        data=response.read(max_bytes+1);headers=dict(response.headers);final=response.url
        if len(data)>max_bytes: raise ValueError('Download exceeds per-file byte bound')
        if response.status!=200: raise ValueError('Unexpected download status')
    sha=hashlib.sha256(data).hexdigest();target=root/(sha+'.bin')
    if not target.exists(): target.write_bytes(data)
    receipt={**job,'status':'saved','sha256':sha,'bytes':len(data),'captured_at':timestamp,'final_url':final,'content_type':headers.get('Content-Type',''),'artifact':target.name}
    with (root/'receipts.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(receipt,ensure_ascii=False)+'\n')
    return receipt

def spl_sections(data):
    """Read SPL XML from a bounded ZIP without extracting archive paths."""
    from xml.etree import ElementTree as ET
    if len(data)>50*1024*1024: raise ValueError('SPL archive is too large')
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        xmls=[i for i in z.infolist() if i.filename.lower().endswith('.xml')]
        if not xmls: raise ValueError('No SPL XML in archive')
        item=max(xmls,key=lambda i:i.file_size)
        if item.file_size>25*1024*1024: raise ValueError('SPL XML exceeds decompression bound')
        raw=z.read(item)
    if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper(): raise ValueError('DTD/entity declarations are not accepted')
    doc=ET.fromstring(raw);ns={'s':'urn:hl7-org:v3'};pages=[]
    for section in doc.findall('.//s:section',ns):
        title=' '.join(section.findtext('s:title',default='',namespaces=ns).split())
        text=section.find('s:text',ns)
        if text is not None:
            pages.append({'label':title or 'Label section','kind':'section','text':' '.join(text.itertext()).strip()})
    return pages

def lookup_case(citation,token,output_dir):
    """Public citation text only; token is never written to receipts or browser config."""
    if not token: raise ValueError('Set COURTLISTENER_TOKEN in the server environment')
    if not isinstance(citation,str) or not 1<=len(citation)<=500: raise ValueError('Submit one citation, not a private document')
    url='https://www.courtlistener.com/api/rest/v4/citation-lookup/'
    req=Request(url,data=urlencode({'text':citation}).encode(),headers={'Authorization':'Token '+token,'User-Agent':UA,'Content-Type':'application/x-www-form-urlencoded'},method='POST')
    with build_opener(SourceRedirect()).open(req,timeout=30) as r:
        raw=r.read(4*1024*1024+1)
        if len(raw)>4*1024*1024:raise ValueError('Citation lookup response too large')
    data=json.loads(raw)
    if not isinstance(data,list):raise ValueError('Unexpected citation lookup response')
    root=Path(output_dir);root.mkdir(parents=True,exist_ok=True);sha=hashlib.sha256(raw).hexdigest();(root/(sha+'.json')).write_bytes(raw)
    outcomes=[{'citation':x.get('citation'),'normalized_citations':x.get('normalized_citations',[]),'status':x.get('status'),'error':x.get('error_message'),
               'candidates':[{'provider_id':c.get('id'),'title':c.get('case_name'),'url':'https://www.courtlistener.com'+c['absolute_url'] if str(c.get('absolute_url','')).startswith('/') else c.get('absolute_url'),'saved_text':False} for c in x.get('clusters',[])]} for x in data]
    receipt={'query':citation,'source_url':url,'sha256':sha,'captured_at':datetime.now(timezone.utc).isoformat(),'outcomes':outcomes,
             'qualification':'External citation resolution only. An identified case is not saved text, support for a proposition, or a good-law determination.'}
    with (root/'case-resolutions.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(receipt)+'\n')
    return receipt

def import_receipts(store,folder):
    from .citations import scan
    from .extraction import extract_pdf
    from html.parser import HTMLParser
    class Reader(HTMLParser):
        def __init__(self):super().__init__();self.skip=0;self.text=[]
        def handle_starttag(self,t,a):
            if t in ('script','style','noscript'):self.skip+=1
            elif t in ('p','div','br','h1','h2','h3','li','tr'):self.text.append('\n')
        def handle_endtag(self,t):
            if t in ('script','style','noscript') and self.skip:self.skip-=1
        def handle_data(self,d):
            if not self.skip:self.text.append(d)
    root=Path(folder).resolve();count=0;held=[]
    for line in (root/'receipts.jsonl').read_text(encoding='utf-8').splitlines():
        rec=json.loads(line)
        if rec.get('status')!='saved' or rec.get('kind')=='label-history':continue
        path=(root/rec['artifact']).resolve()
        if not path.is_relative_to(root) or not path.is_file():raise ValueError('Receipt artifact outside enrichment directory')
        data=path.read_bytes()
        if hashlib.sha256(data).hexdigest()!=rec['sha256']:raise ValueError('Receipt hash mismatch')
        pages=[];partial=False
        if data.startswith(b'%PDF-'):
            ex=extract_pdf(path);pages=ex['pages'];partial=ex['partial']
        elif rec.get('kind')=='label' and data.startswith(b'PK'):
            pages=spl_sections(data)
        elif 'html' in rec.get('content_type',''):
            parser=Reader();parser.feed(data.decode('utf-8','replace'));pages=[{'label':'Saved HTML text','kind':'text_segment','text':''.join(parser.text).strip()}]
        else:held.append({'id':rec['id'],'reason':'Metadata only; unsupported original representation'})
        collection='enriched-'+rec.get('kind','source');store.collection(collection,collection.replace('-',' ').title(),hub='federal' if rec.get('kind')!='opinion' else 'courts')
        record={'collection':collection,'source_id':rec['source_id'],'title':rec.get('title') or rec['url'],'source_url':rec['url'],'kind':rec.get('kind','document'),
                'published_at':rec.get('published_at'),'captured_at':rec['captured_at'],'original_sha256':rec['sha256'],'partial':partial,
                'snapshot':f"SPL version {rec['spl_version']}" if rec.get('spl_version') else None,
                'qualification':rec.get('qualification','Saved official source; verify legal currency and interpretation.')}
        if rec.get('setid'):record['entities']=[{'namespace':'dailymed.setid','id':rec['setid'],'label':rec['setid'],'basis':'Publisher SET ID retained in download request and source history'}]
        r=store.ingest(record,pages);scan(store,r['version_id']);count+=1
    return {'imported':count,'held':held,'originals_modified':False}
