/**
 * Optional application-side integration. Not installed in your production app.
 * The host must authenticate, authorize and resolve source IDs in its own backend.
 * `receive` stores a pending evidence attachment; it must not start an AI task.
 */
export function validateEvidencePackage(value) {
  if (!value || value.schema_version !== 1 || value.type !== 'corpus_evidence_handoff' || value.submitted !== false)
    throw new Error('Expected an unsubmitted version-1 evidence package');
  if (!['research','office','discovery','export'].includes(value.target)) throw new Error('Unknown evidence destination');
  if (!Array.isArray(value.records) || value.records.length < 1 || value.records.length > 50) throw new Error('Choose 1–50 records');
  const size = JSON.stringify(value).length;
  if (size > 1600000) throw new Error('Evidence package too large');
  const seen = new Set();
  for (const record of value.records) {
    for (const name of ['id','version_id','source_id','collection','text_hash','qualification'])
      if (typeof record[name] !== 'string' || !record[name].trim()) throw new Error(`Missing ${name}`);
    if (!record.id.startsWith('rec-') || !record.version_id.startsWith('ver-')) throw new Error('Invalid workbench identity');
    const key = `${record.id}|${record.version_id}`;
    if (seen.has(key)) throw new Error('Duplicate source version');
    seen.add(key);
    if (!Array.isArray(record.excerpts) || record.excerpts.length > 3) throw new Error('Invalid excerpt count');
    for (const excerpt of record.excerpts)
      if (typeof excerpt.text !== 'string' || excerpt.text.length > 3000) throw new Error('Invalid excerpt size');
  }
  return structuredClone(value);
}

export function installEvidenceReceiver({workbenchOrigin,sourceWindow,confirm,receive,windowObject=window}) {
  const u = new URL(workbenchOrigin);
  if (!['https:','http:'].includes(u.protocol) || u.origin !== workbenchOrigin || u.username || u.password)
    throw new Error('An exact trusted workbench origin is required');
  if (![sourceWindow,confirm,receive].every(f=>typeof f==='function')) throw new Error('Source, confirmation and receipt callbacks are required');
  const delivered = new Map();
  const listener = async event => {
    if (event.origin !== workbenchOrigin || event.source !== sourceWindow() || event.data?.type !== 'corpus.evidence.handoff') return;
    const requestId = event.data.requestId;
    if (typeof requestId !== 'string' || !/^[\w-]{1,100}$/.test(requestId)) return;
    const reply = result => event.source.postMessage({type:'corpus.evidence.ack',requestId,...result},workbenchOrigin);
    if (delivered.has(requestId)) { reply(await delivered.get(requestId)); return; }
    const task = (async()=>{
      try {
        const payload = validateEvidencePackage(event.data.payload);
        if (await confirm(payload) !== true) return {accepted:false,reason:'Not approved by the user'};
        const receipt = await receive(payload,{requestId});
        if (receipt?.received !== true) return {accepted:false,reason:'Application did not confirm storage'};
        return {accepted:true,submitted:false};
      } catch { return {accepted:false,reason:'Evidence validation or application authorization failed'}; }
    })();
    delivered.set(requestId,task);
    if (delivered.size > 500) delivered.delete(delivered.keys().next().value);
    reply(await task);
  };
  windowObject.addEventListener('message',listener);
  return ()=>windowObject.removeEventListener('message',listener);
}
