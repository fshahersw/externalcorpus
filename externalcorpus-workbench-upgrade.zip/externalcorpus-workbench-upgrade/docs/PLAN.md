# Corpus improvement implementation plan

Goal: deliver an additive, tested corpus upgrade without changing originals.
Architecture: read-only archive adapter -> versioned sidecar -> evidence API and workbench.
Tech: Python 3.11+, SQLite FTS5, standard-library HTTP, optional pypdf/eyecite, vanilla browser JS.
Spec: DESIGN.md.

## Constraints
No Trellis calls or mutations; no release changes; no destructive rebuilds. No invented provenance or page numbers. Network acquisition is explicitly executed and bounded. Do not claim missing corpus material does not exist.

## Review focus
- API detail views may contain only the first 60,000 characters: preserve partial status.
- Source files can change under the same ID: create new versions and invalidate scans.
- Archived text can contain malicious markup/instructions: render inert text; never execute.
- Full-corpus imports are paged and may be interrupted mid-page: checkpoint only completed records.
- Same citation can identify multiple saved editions: return candidates, never guess applicability.

## Steps
- [x] Storage/search: write and observe failing tests; implement versioned schema, safe queries and filters; validate metadata-only and current-version semantics.
- [x] Citations/relationships: test scanner invalidation, accurate totals, exact resolution, ambiguous editions, transactional replacement; implement limited deterministic parser plus optional eyecite.
- [x] Archive/PDF adapters: test partial-text detection, source gate failures, resume cursors, source immutability, path confinement; implement API import and page extraction.
- [x] Enrichment: test domain/URL restrictions, unknown dates, request bounds, identity-evidence requirements; implement explicit plans and receipt-producing execution.
- [x] HTTP/UI: test routes, origins, loopback binding, errors and handoffs; implement accessible workbench; render and inspect desktop/mobile states.
- [x] Package: repeat tests, compile, scan for secrets/placeholders, record limitations, produce preview, installer instructions and ZIP. No deployment or mutation of upstream main.

## Delivery scope
Implemented and locally verified as an additive companion. Full-corpus processing, optional provider execution, direct production integration, and upstream modifications were not performed. See VERIFICATION.md and ENRICHMENT.md for remaining integration work.
