/* Standalone visual demo only. Live search uses the Python SQLite/BM25 service. */
(()=>{'use strict';
const D=window.WB_PREVIEW_DATA,copy=x=>JSON.parse(JSON.stringify(x));
function record(id,vid){vid=vid||D.search.results.find(x=>x.id===id)?.version_id;const r=D.records[id+'|'+vid];if(!r)throw Error('Unknown preview record or version');return copy(r);}
function paginate(obj,p){const page=Number(p.page||1),limit=Number(p.limit||25);if(!Number.isInteger(page)||page<1||!Number.isInteger(limit)||limit<1||limit>100)throw Error('Invalid pagination');const all=obj.results||[];return {...copy(obj),results:copy(all.slice((page-1)*limit,page*limit)),total:all.length,returned:all.slice((page-1)*limit,page*limit).length,page,limit,has_more:page*limit<all.length};}
window.WB_PREVIEW_API=async(path,options={})=>{
 const u=new URL(path,'http://preview.local'),p=Object.fromEntries(u.searchParams),route=u.pathname;
 if(route==='/api/config')return {demo:true,archive_url:'http://127.0.0.1:8769',platform_origin:'',csrf_token:'offline-preview'};
 if(route==='/api/health')return copy(D.health);
 if(route==='/api/search'){
  const q=(p.q||'').trim().toLowerCase(),match=p.match||'all';
  const tokens=match==='phrase'?[q]:[...q.matchAll(/"([^"]+)"|([\p{L}\p{N}]+(?:[.\-][\p{L}\p{N}]+)*)/gu)].map(m=>m[1]||m[2]);
  const results=D.search.results.filter(r=>{
   if(p.collection&&r.collection!==p.collection||p.jurisdiction&&r.jurisdiction!==p.jurisdiction||p.availability&&r.availability!==p.availability||p.kind&&r.kind!==p.kind)return false;
   const full=record(r.id,r.version_id),text=[r.title,r.citation,...full.pages.map(p=>p.text)].join(' ').toLowerCase();
   return !q||tokens.length>0&&(match==='any'?tokens.some(t=>text.includes(t)):tokens.every(t=>text.includes(t)));
  });
  if(q)results.sort((a,b)=>tokens.filter(t=>b.title.toLowerCase().includes(t)).length-tokens.filter(t=>a.title.toLowerCase().includes(t)).length||a.title.localeCompare(b.title));
  return paginate({...D.search,query:p.q||'',match,results,elapsed_ms:0,coverage:D.search.coverage.filter(c=>!p.collection||c.id===p.collection),qualification:'Offline illustrative search. This does not benchmark the live BM25 engine.'},p);
 }
 if(route==='/api/record'){const r=record(p.id,p.version_id),start=Number(p.start||0),limit=Number(p.limit||5),total=r.pages.length;r.pages=r.pages.slice(start,start+limit);return {...r,total_pages:total,next_page:start+limit<total?start+limit:null};}
 if(route==='/api/citations'){const r=record(p.id,p.version_id);return paginate(D.citations[r.id+'|'+r.version_id],p);}
 if(route==='/api/related'){const r=record(p.id,p.version_id);return copy(D.related[r.id+'|'+r.version_id]);}
 if(route==='/api/cited-by')return paginate(D.inbound[p.q]||{results:[],qualification:'Illustrative saved-document citations only.'},p);
 if(route==='/api/resolve')return copy(D.resolutions[p.q]||{status:'unresolved',candidates:[],qualification:'No exact fixture match.'});
 if(route==='/api/compare'){const a=record(p.left,p.left_version),b=record(p.right,p.right_version);return copy(D.comparisons[[a.id,a.version_id,b.id,b.version_id].join('|')]);}
 if(route==='/api/handoff'){
  const payload=JSON.parse(options.body||'{}'),items=payload.items||[],target=payload.target||'research';
  if(!['research','office','discovery','export'].includes(target)||items.length<1||items.length>50)throw Error('Choose 1–50 sources and a known destination');
  const records=items.map(i=>{const r=record(i.id,i.version_id),out={};for(const k of ['id','version_id','source_id','collection','title','citation','source_url','original_url','text_hash','qualification','published_at','captured_at','snapshot','rights','availability'])out[k]=r[k]??null;out.excerpts=r.pages.slice(0,3).map(p=>({label:p.label,location_kind:p.location_kind,text:p.text.slice(0,3000),excerpt_truncated:p.text.length>3000}));out.pages_omitted=Math.max(0,r.pages.length-3);return out;});
  return {schema_version:1,type:'corpus_evidence_handoff',target,created_at:new Date().toISOString(),submitted:false,records,instruction:'ILLUSTRATIVE FIXTURES ONLY. Preserve evidence qualifications. No downstream task was submitted.'};
 }
 throw Error('Unknown preview endpoint');
};})();
