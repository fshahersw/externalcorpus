@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  python -m corpus_workbench demo --open
) else (
  py -3 -m corpus_workbench demo --open
)
if errorlevel 1 pause
