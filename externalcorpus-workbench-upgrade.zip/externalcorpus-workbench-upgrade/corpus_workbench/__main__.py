"""Run `python -m corpus_workbench --help`. All writes stay in a marked sidecar directory."""
import argparse,json,sys,time,os,tempfile,webbrowser,uuid
from pathlib import Path
from .store import Store
from .archive import COLLECTIONS,ArchiveClient,sync,import_jsonl
from .citations import scan

def state_dir(path):
    p=Path(path).resolve();marker=p/'.corpus-workbench'
    if p.exists() and any(p.iterdir()) and not marker.is_file():
        raise ValueError('Refusing an existing unmarked directory. Choose a new workbench-state directory, not your original corpus.')
    p.mkdir(parents=True,exist_ok=True);marker.write_text('Corpus Workbench sidecar schema 1\n');return p

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--state',default='workbench-state',help='Separate marked sidecar folder, never an original collection')
    sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('serve');p.add_argument('--port',type=int,default=8770);p.add_argument('--open',action='store_true');p.add_argument('--archive-url',default='http://127.0.0.1:8769');p.add_argument('--platform-origin',default='')
    p=sub.add_parser('demo');p.add_argument('--port',type=int,default=8770);p.add_argument('--open',action='store_true')
    p=sub.add_parser('sync');p.add_argument('--collection',choices=list(COLLECTIONS)+['all'],default='court-documents');p.add_argument('--archive-url',default='http://127.0.0.1:8769');p.add_argument('--max-records',type=int,default=250);p.add_argument('--max-seconds',type=int,default=120);p.add_argument('--refresh',action='store_true');p.add_argument('--extract-originals',action='store_true')
    p=sub.add_parser('import-jsonl');p.add_argument('path')
    p=sub.add_parser('scan');p.add_argument('--max-records',type=int,default=1000)
    p=sub.add_parser('health')
    p=sub.add_parser('extract-pdf');p.add_argument('path');p.add_argument('--source-id',required=True);p.add_argument('--title',required=True);p.add_argument('--source-url',default='');p.add_argument('--jurisdiction',default='UNKNOWN');p.add_argument('--ocr',action='store_true')
    p=sub.add_parser('enrich-plan');p.add_argument('input');p.add_argument('--kind',choices=['warning-letter','settlement','opinion','label'],required=True)
    p=sub.add_parser('enrich-run');p.add_argument('plan');p.add_argument('--execute',action='store_true');p.add_argument('--max-jobs',type=int,default=10)
    p=sub.add_parser('label-history');p.add_argument('setid');p.add_argument('--execute',action='store_true');p.add_argument('--from-json');p.add_argument('--max-pages',type=int,default=10)
    p=sub.add_parser('case-lookup');p.add_argument('citation');p.add_argument('--execute',action='store_true')
    p=sub.add_parser('import-receipts');p.add_argument('--folder')
    p=sub.add_parser('preview');p.add_argument('--output',default='corpus-workbench-preview.html')
    args=parser.parse_args()
    if args.command=='preview':
        from .preview import build_preview
        build_preview(Path(args.output));print('Created '+args.output);return 0
    if args.command=='demo':
        from .demo import seed
        from .server import make_server
        with tempfile.TemporaryDirectory(prefix='corpus-demo-') as d:
            store=Store(Path(d)/'demo.db');seed(store);server=make_server(store,port=args.port,demo=True)
            address=f'http://127.0.0.1:{server.server_address[1]}';print('Illustrative demo only: '+address,flush=True)
            if args.open:webbrowser.open(address)
            try:server.serve_forever()
            finally:server.server_close()
        return 0
    root=state_dir(args.state);store=Store(root/'evidence.sqlite3')
    if args.command=='serve':
        from .server import make_server
        ArchiveClient(args.archive_url)
        server=make_server(store,port=args.port,archive_url=args.archive_url,platform_origin=args.platform_origin)
        address=f'http://127.0.0.1:{server.server_address[1]}';print('Local workbench: '+address,flush=True)
        if args.open:webbrowser.open(address)
        try:server.serve_forever()
        finally:server.server_close()
        return 0
    elif args.command=='sync':
        client=ArchiveClient(args.archive_url);results=[]
        targets=list(COLLECTIONS) if args.collection=='all' else [args.collection]
        for c in targets:
            r=sync(store,client,c,args.max_records,args.max_seconds,args.refresh,args.extract_originals);results.append({'collection':c,**r});print(json.dumps(results[-1]),flush=True)
        return 1 if any(r['status'] in ('paused','unavailable') for r in results) else 0
    elif args.command=='import-jsonl':result=import_jsonl(store,args.path)
    elif args.command=='health':result=store.health()
    elif args.command=='scan':
        if not 1<=args.max_records<=100000:raise ValueError('Invalid scan bound')
        from .citations import effective_version
        with store.connect() as db:ids=[r[0] for r in db.execute("SELECT v.id FROM versions v JOIN records r ON r.current_version=v.id WHERE v.scan_status!='scanned' OR v.scan_version!=? LIMIT ?",(effective_version(),args.max_records))]
        result={'scanned':[scan(store,id) for id in ids]}
    elif args.command=='extract-pdf':
        from .extraction import extract_pdf,ocr_derivative
        path=Path(args.path)
        if args.ocr:path=ocr_derivative(path,root/'ocr-derivatives')
        extracted=extract_pdf(path);store.collection('court-pages','Court document pages',hub='courts')
        r=store.ingest({'collection':'court-pages','source_id':args.source_id,'title':args.title,'source_url':args.source_url,'jurisdiction':args.jurisdiction,
                        'partial':extracted['partial'],'original_sha256':extracted['original_sha256'],'extraction_method':extracted['method'],'qualification':extracted['qualification']},extracted['pages']);scan(store,r['version_id'])
        result={**r,'needs_ocr':extracted['needs_ocr'],'total_pages':extracted['total_pages'],'originals_modified':False}
    elif args.command=='enrich-plan':
        from .enrich import plan_jobs
        records=[json.loads(l) for l in Path(args.input).read_text(encoding='utf-8-sig').splitlines() if l.strip()]
        jobs=plan_jobs(records,args.kind);p=root/f'{args.kind}-plan.json';p.write_text(json.dumps(jobs,indent=2),encoding='utf-8');result={'planned':len(jobs),'plan':str(p),'executed':False}
    elif args.command=='enrich-run':
        from .enrich import fetch_job
        jobs=json.loads(Path(args.plan).read_text(encoding='utf-8'));result={'planned':len(jobs),'executed':False}
        if args.execute:
            if not 1<=args.max_jobs<=1000:raise ValueError('Use 1–1000 jobs per bounded pass')
            done=[];out=root/'enrichment';seen=set()
            if (out/'receipts.jsonl').exists():seen={r['id'] for l in (out/'receipts.jsonl').read_text().splitlines() if (r:=json.loads(l)).get('status')=='saved'}
            for job in jobs:
                if job['id'] in seen:continue
                if len(done)>=args.max_jobs:break
                try:done.append(fetch_job(job,out))
                except Exception as e:done.append({'id':job['id'],'status':'held','error':str(e)[:180]})
            result={'executed':True,'jobs':done,'remaining_not_attempted':max(0,len(jobs)-len(seen)-len(done))}
    elif args.command=='label-history':
        from .enrich import fetch_job,label_history_jobs
        setid=str(uuid.UUID(args.setid));jobs=[];complete=False
        if args.from_json:
            data=json.loads(Path(args.from_json).read_text());jobs=label_history_jobs(setid,data);complete=str(data.get('metadata',{}).get('next_page','null')).lower() in ('null','none','')
        elif args.execute:
            for page in range(1,min(20,max(1,args.max_pages))+1):
                url=f'https://dailymed.nlm.nih.gov/dailymed/services/v2/spls/{setid}/history.json?page={page}'
                r=fetch_job({'id':setid+'-history-'+str(page),'kind':'label-history','url':url,'source_id':setid},root/'enrichment');data=json.loads((root/'enrichment'/r['artifact']).read_text());jobs.extend(label_history_jobs(setid,data))
                if str(data.get('metadata',{}).get('next_page','null')).lower() in ('null','none',''):complete=True;break
        else:
            print(json.dumps({'executed':False,'history_url':f'https://dailymed.nlm.nih.gov/dailymed/services/v2/spls/{setid}/history.json','next':'Add --execute to fetch history; label downloads remain separately planned.'}));return 0
        p=root/'label-versions-plan.json';p.write_text(json.dumps(jobs,indent=2));result={'versions_planned':len(jobs),'history_complete':complete,'plan':str(p),'labels_downloaded':False}
    elif args.command=='case-lookup':
        from .enrich import lookup_case
        result=lookup_case(args.citation,os.environ.get('COURTLISTENER_TOKEN',''),root/'enrichment') if args.execute else {'executed':False,'citation':args.citation,'next':'Set COURTLISTENER_TOKEN and add --execute. Only the citation text is sent.'}
    elif args.command=='import-receipts':
        from .enrich import import_receipts
        result=import_receipts(store,args.folder or root/'enrichment')
    print(json.dumps(result,indent=2,ensure_ascii=False));return 0

if __name__=='__main__':
    try:sys.exit(main())
    except KeyboardInterrupt:print('\nStopped. Saved source data remains unchanged.');sys.exit(130)
    except Exception as e:print(f'Error: {e}',file=sys.stderr);sys.exit(1)
