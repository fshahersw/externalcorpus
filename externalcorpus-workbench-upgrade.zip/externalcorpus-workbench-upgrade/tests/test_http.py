import unittest,tempfile,importlib.util,json,threading,http.client
from pathlib import Path
from corpus_workbench.store import Store
class HttpTests(unittest.TestCase):
 def setUp(self):
  self.assertIsNotNone(importlib.util.find_spec('corpus_workbench.server'),'HTTP service must exist')
  from corpus_workbench.server import make_server
  self.tmp=tempfile.TemporaryDirectory();self.s=Store(Path(self.tmp.name)/'index.db');self.s.collection('law','Law')
  self.r=self.s.ingest({'collection':'law','source_id':'x','title':'Example'},[{'text':'expert evidence'}])
  self.http=make_server(self.s,port=0);self.port=self.http.server_address[1]
  self.t=threading.Thread(target=self.http.serve_forever,daemon=True);self.t.start()
 def tearDown(self):
  if hasattr(self,'http'):self.http.shutdown();self.http.server_close();self.tmp.cleanup()
 def req(self,path,method='GET',body=None,headers=None):
  c=http.client.HTTPConnection('127.0.0.1',self.port,timeout=3)
  c.request(method,path,body=body,headers=headers or {});r=c.getresponse();data=r.read();code=r.status;c.close();return code,data
 def test_search(self):
  code,data=self.req('/api/search?q=expert');self.assertEqual(code,200);self.assertEqual(json.loads(data)['total'],1)
 def test_bad_query_returns_error(self):
  code,data=self.req('/api/search?page=oops');self.assertEqual(code,400);self.assertIn('error',json.loads(data))
 def test_unknown_record_404(self):self.assertEqual(self.req('/api/record?id=fake')[0],404)
 def test_unknown_api_404(self):self.assertEqual(self.req('/api/not-real')[0],404)
 def test_host_guard(self):self.assertEqual(self.req('/api/health',headers={'Host':'evil.test'})[0],403)
 def test_origin_guard(self):self.assertEqual(self.req('/api/health',headers={'Origin':'https://evil.test'})[0],403)
 def test_path_traversal(self):self.assertEqual(self.req('/static/../../README.md')[0],404)
 def test_no_handoff_without_token(self):self.assertEqual(self.req('/api/handoff','POST','{}',{'Content-Type':'application/json'})[0],403)
 def test_valid_handoff(self):
  _,config=self.req('/api/config');token=json.loads(config)['csrf_token']
  code,data=self.req('/api/handoff','POST',json.dumps({'items':[{'id':self.r['record_id']}],'target':'office'}),{'Content-Type':'application/json','X-Workbench-Token':token})
  self.assertEqual(code,200);self.assertFalse(json.loads(data)['submitted'])
 def test_index(self):
  code,data=self.req('/');self.assertEqual(code,200);self.assertIn(b'Knowledge & sources',data)
 def test_source_mutations_rejected(self):self.assertEqual(self.req('/api/delete','POST','{}')[0],403)
 def test_invalid_loopback_binding(self):
  from corpus_workbench.server import make_server
  with self.assertRaises(ValueError):make_server(self.s,host='0.0.0.0',port=0)
if __name__=='__main__':unittest.main()
