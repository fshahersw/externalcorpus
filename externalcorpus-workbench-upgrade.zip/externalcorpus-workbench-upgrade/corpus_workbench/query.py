"""A deliberately small, injection-safe query language. No raw FTS operators."""
import re

def compile_query(value: str, match: str = 'all') -> str:
    if match not in {'all','any','phrase'}:
        raise ValueError('Match must be all, any, or phrase')
    if not isinstance(value,str) or len(value)>1000:
        raise ValueError('Query must be at most 1,000 characters')
    value=value.strip()
    if not value: return ''
    if match=='phrase':
        words=re.findall(r'\w+',value,flags=re.UNICODE)
        return '"'+' '.join(words)+'"' if words else ''
    terms=[]
    for token in re.findall(r'"[^"]*"|[^\s"]+',value):
        words=re.findall(r'\w+',token,flags=re.UNICODE)
        if not words: continue
        # User quotation is preserved as one phrase; punctuation in bare citations
        # is tokenized consistently with SQLite unicode61.
        if token.startswith('"'): terms.append('"'+' '.join(words)+'"')
        else: terms.extend('"'+w+'"' for w in words)
    if len(terms)>80: raise ValueError('Use at most 80 search terms')
    return (' OR ' if match=='any' else ' AND ').join(terms)

def pagination(page=1,limit=25):
    try:
        p,n=int(page),int(limit)
    except (ValueError,TypeError): raise ValueError('Page and limit must be integers') from None
    if str(p)!=str(page) or str(n)!=str(limit) or not 1<=p<=100000 or not 1<=n<=100:
        raise ValueError('Page must be 1–100000; limit must be 1–100')
    return p,n
