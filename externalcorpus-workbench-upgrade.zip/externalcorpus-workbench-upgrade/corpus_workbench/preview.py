"""Build an offline UI preview from explicitly synthetic evidence, never live data."""
from pathlib import Path
import json,tempfile
from .store import Store
from .demo import seed
from .compare import compare

def build_preview(output):
    static=Path(__file__).parent/'static'
    with tempfile.TemporaryDirectory(prefix='corpus-preview-') as d:
        s=Store(Path(d)/'demo.sqlite3');seed(s)
        search=s.search(limit=100)
        data={'health':s.health(),'search':search,'records':{},'citations':{},'related':{},'inbound':{},'resolutions':{},'comparisons':{}}
        all_versions=[]
        for result in search['results']:
            rid=result['id'];r=s.record(rid)
            for v in r['versions']:
                key=rid+'|'+v['id'];full=s.record(rid,v['id']);data['records'][key]=full
                data['citations'][key]=s.citations(rid,v['id'],limit=100)
                data['related'][key]=s.related(rid,v['id']);all_versions.append((rid,v['id']))
                if full.get('citation'):data['inbound'][full['citation']]=s.cited_by(full['citation'],limit=100)
                for c in data['citations'][key]['results']:data['resolutions'][c['citation']]=c['resolution']
            result['passage']=next(({'text':p['text'],'label':p['label'],'location_kind':p['location_kind'],'page_index':p['page_index']} for p in r['pages'] if p['text']),None)
        for a in all_versions:
            for b in all_versions:
                data['comparisons']['|'.join(a+b)]=compare(s,a[0],b[0],a[1],b[1])
    payload=json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    html=(static/'index.html').read_text(encoding='utf-8')
    html=html.replace('<link rel="stylesheet" href="/static/style.css">','<style>'+(static/'style.css').read_text(encoding='utf-8')+'</style>')
    app=(static/'app.js').read_text(encoding='utf-8');preview=(static/'preview.js').read_text(encoding='utf-8')
    html=html.replace('<script src="/static/app.js"></script>', '<script>window.WB_PREVIEW_DATA='+payload+';</script><script>'+preview.replace('</script','<\\/script')+'</script><script>'+app.replace('</script','<\\/script')+'</script>')
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True);output.write_text(html,encoding='utf-8')
    return output
