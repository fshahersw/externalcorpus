import test from 'node:test';
import assert from 'node:assert/strict';
let receiver;
try { receiver = await import('../integration/platform-receiver.mjs'); } catch {}
const sample=()=>({schema_version:1,type:'corpus_evidence_handoff',target:'research',submitted:false,records:[{id:'rec-123',version_id:'ver-123',source_id:'source1',collection:'law',text_hash:'abc',qualification:'Saved snapshot',excerpts:[]}]});
test('receiver implementation exists',()=>assert.ok(receiver));
test('accepts a typed evidence-only package',()=>assert.equal(receiver.validateEvidencePackage(sample()).target,'research'));
test('rejects executed tasks',()=>assert.throws(()=>receiver.validateEvidencePackage({...sample(),submitted:true})));
test('rejects missing exact version',()=>{const p=sample();delete p.records[0].version_id;assert.throws(()=>receiver.validateEvidencePackage(p));});
test('requires known target',()=>assert.throws(()=>receiver.validateEvidencePackage({...sample(),target:'delete'})));
test('enforces excerpt bounds',()=>{const p=sample();p.records[0].excerpts=[{text:'x'.repeat(3001)}];assert.throws(()=>receiver.validateEvidencePackage(p));});
test('ignores wrong origin and requires confirmation before receive',async()=>{
 let listener,confirmation=0,received=0;const replies=[];
 const host={addEventListener:(n,f)=>listener=f,removeEventListener:()=>{}};const source={postMessage:(message,origin)=>replies.push({message,origin})};
 const off=receiver.installEvidenceReceiver({windowObject:host,workbenchOrigin:'http://127.0.0.1:8770',sourceWindow:()=>source,confirm:async()=>{confirmation++;return true;},receive:async()=>{received++;return {received:true};}});
 const e={origin:'https://evil.example',source,data:{type:'corpus.evidence.handoff',requestId:'request-1',payload:sample()}};
 await listener(e);assert.equal(received,0);
 await listener({...e,origin:'http://127.0.0.1:8770'});assert.equal(confirmation,1);assert.equal(received,1);assert.equal(replies[0].message.accepted,true);
 await listener({...e,origin:'http://127.0.0.1:8770'});assert.equal(received,1);off();
});
test('never acknowledges an unpersisted handoff',async()=>{
 let listener;const replies=[];const host={addEventListener:(n,f)=>listener=f,removeEventListener:()=>{}};const source={postMessage:m=>replies.push(m)};
 receiver.installEvidenceReceiver({windowObject:host,workbenchOrigin:'http://127.0.0.1:8770',sourceWindow:()=>source,confirm:async()=>true,receive:async()=>({received:false})});
 await listener({origin:'http://127.0.0.1:8770',source,data:{type:'corpus.evidence.handoff',requestId:'request-2',payload:sample()}});
 assert.equal(replies[0].accepted,false);
});
