"""Loopback development workbench. Production requires an authenticated app proxy."""
import json,secrets,logging,mimetypes
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from urllib.parse import urlsplit,parse_qs
from pathlib import Path
from .compare import compare
STATIC=Path(__file__).parent/'static'

def make_server(store,host='127.0.0.1',port=8770,demo=False,archive_url='http://127.0.0.1:8769',platform_origin=''):
 if host not in ('127.0.0.1','localhost'):raise ValueError('Workbench binds only to loopback')
 if platform_origin:
  u=urlsplit(platform_origin)
  if u.scheme not in ('https','http') or not u.hostname or u.username or u.password or u.path not in ('','/') or u.query or u.fragment:raise ValueError('Platform origin must be an explicit HTTP(S) origin')
  platform_origin=platform_origin.rstrip('/')
 token=secrets.token_urlsafe(32)
 class Handler(BaseHTTPRequestHandler):
  server_version='CorpusWorkbench/1.0'
  def log_message(self,fmt,*args):pass
  def send(self,status,value,mime='application/json; charset=utf-8'):
   data=json.dumps(value,ensure_ascii=False).encode() if isinstance(value,(dict,list)) else value.encode() if isinstance(value,str) else value
   self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','no-referrer')
   self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors "+(platform_origin or "'none'"))
   self.end_headers()
   try:self.wfile.write(data)
   except (BrokenPipeError,ConnectionResetError):pass
  def allowed(self):
   authority=self.headers.get('Host','');p=self.server.server_address[1]
   if authority not in (f'127.0.0.1:{p}',f'localhost:{p}'):return False
   origin=self.headers.get('Origin')
   if origin and origin not in (f'http://127.0.0.1:{p}',f'http://localhost:{p}'):return False
   if self.headers.get('Sec-Fetch-Site')=='cross-site':return False
   return True
  def do_GET(self):
   if not self.allowed():return self.send(403,{'error':'Loopback same-origin access only'})
   u=urlsplit(self.path);params={k:v[0] for k,v in parse_qs(u.query,keep_blank_values=True).items()};path=u.path
   try:
    if path=='/api/config':return self.send(200,{'demo':demo,'archive_url':archive_url,'platform_origin':platform_origin,'csrf_token':token})
    if path=='/api/health':return self.send(200,store.health())
    if path=='/api/search':return self.send(200,store.search(**params))
    if path=='/api/record':
     value=store.record(params.get('id',''),params.get('version_id'));start=max(0,int(params.get('start','0')));limit=min(10,max(1,int(params.get('limit','5'))));total=len(value['pages'])
     value['pages']=value['pages'][start:start+limit];value['total_pages']=total;value['next_page']=start+limit if start+limit<total else None
     return self.send(200,value)
    if path=='/api/citations':return self.send(200,store.citations(params.pop('id',''),**params))
    if path=='/api/cited-by':return self.send(200,store.cited_by(params.pop('q',''),**params))
    if path=='/api/resolve':return self.send(200,store.resolve(params.get('q','')))
    if path=='/api/related':return self.send(200,store.related(params.get('id',''),params.get('version_id')))
    if path=='/api/compare':return self.send(200,compare(store,params.get('left',''),params.get('right',''),params.get('left_version'),params.get('right_version')))
    if path=='/':return self.send(200,(STATIC/'index.html').read_bytes(),'text/html; charset=utf-8')
    if path in ('/static/app.js','/static/style.css','/static/preview.js'):
     p=STATIC/path.rsplit('/',1)[1];return self.send(200,p.read_bytes(),'text/javascript; charset=utf-8' if p.suffix=='.js' else 'text/css; charset=utf-8')
    return self.send(404,{'error':'Not found'})
   except KeyError as e:return self.send(404,{'error':str(e).strip("'")})
   except (ValueError,TypeError) as e:return self.send(400,{'error':str(e)})
   except Exception:
    logging.exception('Workbench request failed');return self.send(503,{'error':'Evidence service unavailable. No search result is asserted.'})
  def do_POST(self):
   if not self.allowed() or not secrets.compare_digest(self.headers.get('X-Workbench-Token',''),token):return self.send(403,{'error':'Same-origin request token required'})
   if urlsplit(self.path).path!='/api/handoff':return self.send(405,{'error':'Source mutations are not supported'})
   try:
    n=int(self.headers.get('Content-Length','0'))
    if not 0<n<=128000:raise ValueError('Invalid request size')
    payload=json.loads(self.rfile.read(n));return self.send(200,store.handoff(payload.get('items',[]),payload.get('target','research')))
   except KeyError as e:return self.send(404,{'error':str(e)})
   except (ValueError,TypeError,AttributeError) as e:return self.send(400,{'error':str(e)})
   except Exception:return self.send(503,{'error':'Unable to prepare evidence package'})
 return ThreadingHTTPServer((host,port),Handler)
