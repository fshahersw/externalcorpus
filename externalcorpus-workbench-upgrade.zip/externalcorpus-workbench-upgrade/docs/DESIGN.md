# Corpus Workbench upgrade

Approved intent: improve search, citations, connections, evidence retrieval, and UI/UX for fshahersw/externalcorpus. Do not modify Trellis, release assets, licensing decisions, credentials, original collections, or the production platform.

Implementation: a separate Python package and loopback web app. It reads the archive's existing read-only, validation-gated HTTP APIs; creates a separately versioned SQLite sidecar; indexes page-addressable passages; retains source IDs, qualifications, dates, and links. Trellis-specific endpoints are not called. Original data is neither rewritten nor redistributed. Existing archive UI remains available at its original address.

Search: safe phrase/all-word/any-word syntax, BM25 with title/citation weighting, exact totals, stable pagination, availability/jurisdiction/source filters, explicit searched/partial/unavailable collection coverage. Plain queries are not forced into phrases. Metadata-only matches are visibly identified.

Evidence: immutable per-record versions including metadata, canonical text hashes, truthful page versus text-segment anchors, parser-version-aware rescan, failed scans retryable, no 80-authority display ceiling, exact local citation resolution with ambiguous candidates kept separate, evidence-backed entity links only. All derivations are qualified; no legal validity/causation claims.

Integration: bounded, resumable imports through existing APIs; optional native-PDF extraction of originals through those APIs; OCR-needed pages remain flagged; JSONL ingestion for existing extraction engines; explicit bounded external enrichment jobs with stored receipts. No paid inference or automatic full-corpus acquisition. Research/Office/Discovery receive validated evidence packages, not auto-submitted work.

UI: light professional navy/white design; three original browsing hubs; one source-aware search; list/reader split; accessible filters and mobile navigation; citations, related evidence, versions, comparison, session evidence tray, source health. Live and illustrative preview modes are unmistakably different. Original archive and platform app links are configured, not invented.

Validation: unit tests against actual temporary SQLite databases and extraction text; fixture HTTP importer tests; browser checks at 1440 and 390px; no unverified full-corpus or production-performance claims. Network unavailable in this container; the complete archive is not mounted. Delivered code is not deployed until the user runs the launcher beside their restored corpus.
